import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import prisma from '@/lib/prisma'

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const { message } = body

    if (!message || !message.trim()) {
      return NextResponse.json({ error: 'Message is required' }, { status: 400 })
    }

    const ticket = await prisma.ticket.findUnique({
      where: { id: params.id },
    })

    if (!ticket) {
      return NextResponse.json({ error: 'Ticket not found' }, { status: 404 })
    }

    if (ticket.userId !== session.user.id) {
      const isStaff = ['HELPER', 'ADMIN', 'HEAD_ADMIN', 'CO_OWNER', 'OWNER'].includes(session.user.role)
      if (!isStaff) {
        return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
      }
    }

    const newMessage = await prisma.ticketMessage.create({
      data: {
        ticketId: params.id,
        userId: session.user.id,
        message: message.trim(),
        isStaff: ['HELPER', 'ADMIN', 'HEAD_ADMIN', 'CO_OWNER', 'OWNER'].includes(session.user.role),
      },
      include: {
        user: {
          select: { minecraftUsername: true, role: true },
        },
      },
    })

    await prisma.ticket.update({
      where: { id: params.id },
      data: { updatedAt: new Date() },
    })

    return NextResponse.json(newMessage)
  } catch (error) {
    console.error('Failed to send message:', error)
    return NextResponse.json({ error: 'Failed to send message' }, { status: 500 })
  }
}