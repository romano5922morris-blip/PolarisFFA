'use client'

import { Card, CardContent } from '@/components/ui/card'
import { Zap, Shield, Users, Award, Globe, Lock, Heart, Bolt, Star, Crown, Gem, Sparkles } from 'lucide-react'

const features = [
  {
    icon: Zap,
    title: 'Lightning Fast Combat',
    description: 'Custom hit registration and anti-lag systems ensure every hit counts. No more phantom hits or delayed damage.',
  },
  {
    icon: Shield,
    title: 'Advanced Anti-Cheat',
    description: 'Multi-layered cheat detection with machine learning. Automatic bans for blatant cheaters, manual review for suspicious activity.',
  },
  {
    icon: Users,
    title: 'Thriving Community',
    description: 'Join 10,000+ registered players. Active Discord, regular events, tournaments, and a helpful staff team.',
  },
  {
    icon: Award,
    title: 'Fair Progression System',
    description: 'Earn ranks through gameplay or purchase cosmetics. No pay-to-win mechanics. Skill is rewarded equally.',
  },
  {
    icon: Globe,
    title: 'Global Low Latency',
    description: 'Multiple server locations worldwide. Automatic routing to nearest node for optimal ping wherever you play.',
  },
  {
    icon: Lock,
    title: 'Secure Infrastructure',
    description: 'DDoS protection, encrypted connections, and regular security audits. Your data and gameplay are safe.',
  },
  {
    icon: Heart,
    title: 'Regular Content Updates',
    description: 'Weekly updates with balance changes, new cosmetics, map rotations, and seasonal content. Never gets stale.',
  },
  {
    icon: Bolt,
    title: 'Unique Combat Mechanics',
    description: 'Spear reach system, Mace physics, Diamond parry mechanics. Custom PvP you can\'t experience anywhere else.',
  },
  {
    icon: Star,
    title: 'Cosmetic Collection',
    description: 'Hundreds of particle trails, kill effects, join messages, pets, and more. Collect and show off your style.',
  },
  {
    icon: Crown,
    title: 'Ranked Seasons',
    description: 'Competitive seasonal ladder with exclusive rewards. Climb from Iron to Polaris rank each season.',
  },
  {
    icon: Gem,
    title: 'Custom Maps',
    description: 'Hand-crafted FFA maps designed for each combat style. Regular map rotations keep gameplay fresh.',
  },
  {
    icon: Sparkles,
    title: 'Quality of Life',
    description: 'Auto-rejoin, kill feed, damage indicators, combat log, statistics tracking, and much more.',
  },
]

export function Features() {
  return (
    <section className="py-16 sm:py-24 lg:py-32 bg-polaris-950">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl sm:text-5xl font-bold text-white mb-4">Why Choose PolarisFFA?</h2>
            <p className="text-polaris-400 text-lg max-w-2xl mx-auto">
              Built by PvP enthusiasts, for PvP enthusiasts. Every feature designed to enhance your competitive experience.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, index) => (
              <Card key={index} className="group h-full bg-polaris-900/50 border-polaris-800 hover:border-polaris-700 hover:shadow-xl hover:shadow-polaris-500/10 transition-all duration-300">
                <CardContent className="p-6">
                  <div className="p-3 rounded-xl bg-polaris-800/50 border border-polaris-800 group-hover:border-polaris-700 group-hover:bg-polaris-500/10 transition-all duration-300 mb-4">
                    <feature.icon className="h-6 w-6 text-polaris-400 group-hover:text-polaris-300 transition-colors" aria-hidden="true" />
                  </div>
                  <h3 className="text-lg font-semibold text-white mb-2">{feature.title}</h3>
                  <p className="text-polaris-400 text-sm leading-relaxed">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}