'use client'

import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Copy, ArrowRight, Server, Users, Zap } from 'lucide-react'
import { useState } from 'react'
import { cn } from '@/lib/utils'

export function Hero() {
  const [copied, setCopied] = useState(false)

  const copyIP = async () => {
    await navigator.clipboard.writeText('play.polarisffa.eu')
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <section className="relative min-h-[90vh] flex items-center justify-center overflow-hidden bg-polaris-950">
      <div className="absolute inset-0 bg-gradient-to-b from-polaris-900/50 via-transparent to-polaris-950" aria-hidden="true" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-polaris-900/20 via-transparent to-transparent" aria-hidden="true" />
      <div className="absolute inset-0 bg-grid-pattern" aria-hidden="true" />
      
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-polaris-500/10 rounded-full blur-3xl animate-pulse-glow" aria-hidden="true" />
      <div className="absolute top-1/4 left-1/4 w-[400px] h-[400px] bg-polaris-400/5 rounded-full blur-3xl animate-float" aria-hidden="true" />
      <div className="absolute bottom-1/4 right-1/4 w-[300px] h-[300px] bg-polaris-600/5 rounded-full blur-3xl animate-float" style={{ animationDelay: '2s' }} aria-hidden="true" />

      <div className="relative container mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="max-w-4xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-polaris-900/50 border border-polaris-800 text-polaris-300 text-sm font-medium mb-8 animate-in">
            <Zap className="h-4 w-4 text-polaris-400" aria-hidden="true" />
            <span>Spear • Mace • Diamond SMP</span>
          </div>
          
          <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold tracking-tight text-white mb-6 animate-in" style={{ animationDelay: '100ms' }}>
            PolarisFFA
          </h1>
          
          <p className="text-xl sm:text-2xl text-polaris-300 max-w-2xl mx-auto mb-10 leading-relaxed animate-in" style={{ animationDelay: '200ms' }}>
            The ultimate Minecraft FFA experience. Competitive PvP with unique combat mechanics, 
            progression systems, and a thriving community.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12 animate-in" style={{ animationDelay: '300ms' }}>
            <Link href="/store">
              <Button size="xl" className="group w-full sm:w-auto gap-2 bg-gradient-to-r from-polaris-600 to-polaris-400 hover:from-polaris-500 hover:to-polaris-300 shadow-lg shadow-polaris-500/30">
                Play Now
                <ArrowRight className="h-5 w-5 transition-transform group-hover:translate-x-1" aria-hidden="true" />
              </Button>
            </Link>
            <Link href="/store">
              <Button size="xl" variant="outline" className="w-full sm:w-auto gap-2 border-polaris-600 hover:bg-polaris-600/10">
                View Store
              </Button>
            </Link>
            <a href="https://discord.gg/HutBfhABcJ" target="_blank" rel="noopener noreferrer">
              <Button size="xl" variant="secondary" className="w-full sm:w-auto gap-2">
                <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                  <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.442.747-.694 1.113a18.8 18.8 0 0 0-5.453 0 13.53 13.53 0 0 0-.711-1.113.077.077 0 0 0-.079-.037A19.735 19.735 0 0 0 3.676 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.083.083 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028 14.09 14.09 0 0 0 1.226-1.994.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.007-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 0 7.303-2.122 8.93-5.199a.077.077 0 0 1 .077-.01c2.59 0 4.962 1.065 6.648 2.764a.076.076 0 0 1 .032.054 19.914 19.914 0 0 0 5.07-4.329.077.077 0 0 0-.029-.079zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.419-2.157 2.419zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.419-2.157 2.419z" />
                </svg>
                Join Discord
              </Button>
            </a>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-6 text-polaris-400 animate-in" style={{ animationDelay: '400ms' }}>
            <div className="flex items-center gap-3 px-4 py-3 rounded-xl bg-polaris-900/50 border border-polaris-800">
              <Server className="h-5 w-5 text-polaris-400" aria-hidden="true" />
              <div className="text-left">
                <p className="text-xs text-polaris-500 uppercase tracking-wider">Server IP</p>
                <code className="text-base font-mono text-white">play.polarisffa.eu</code>
              </div>
              <Button variant="ghost" size="icon" onClick={copyIP} className="h-8 w-8 ml-2" aria-label="Copy server IP">
                {copied ? (
                  <>
                    <svg className="h-4 w-4 text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                    <span className="sr-only">Copied</span>
                  </>
                ) : (
                  <Copy className="h-4 w-4" aria-hidden="true" />
                )}
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce" aria-hidden="true">
        <svg className="h-6 w-6 text-polaris-500/50" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
        </svg>
      </div>
    </section>
  )
}