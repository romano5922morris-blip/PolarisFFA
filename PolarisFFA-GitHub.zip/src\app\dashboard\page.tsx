'use client'

import { useSession } from 'next-auth/react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { formatPrice, formatDateTime, getRoleHierarchy } from '@/lib/utils'

function getRoleBadgeVariant(role: string): "role-user" | "role-helper" | "role-admin" | "role-head_admin" | "role-co_owner" | "role-owner" {
  const roleLower = role.toLowerCase().replace('_', '_')
  return `role-${roleLower}` as "role-user" | "role-helper" | "role-admin" | "role-head_admin" | "role-co_owner" | "role-owner"
}
import Link from 'next/link'
import { Crown, Package, History, User, Mail, Settings, Shield, ArrowRight, Loader2 } from 'lucide-react'
import { useEffect, useState } from 'react'

interface Purchase {
  id: string
  productId: string
  grantedAt: string
  expiresAt: string | null
  active: boolean
  product: {
    id: string
    name: string
    price: number
    type: string
    metadata: Record<string, unknown> | null
  }
}

interface Order {
  id: string
  status: string
  total: number
  createdAt: string
  items: Array<{
    id: string
    productId: string
    price: number
    quantity: number
    product: {
      name: string
    }
  }>
}

export default function DashboardPage() {
  const { data: session } = useSession()
  const [purchases, setPurchases] = useState<Purchase[]>([])
  const [orders, setOrders] = useState<Order[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchData()
  }, [])

  const fetchData = async () => {
    try {
      const [purchasesRes, ordersRes] = await Promise.all([
        fetch('/api/user/purchases'),
        fetch('/api/user/orders'),
      ])

      if (purchasesRes.ok) setPurchases(await purchasesRes.json())
      if (ordersRes.ok) setOrders(await ordersRes.json())
    } catch (error) {
      console.error('Failed to fetch dashboard data:', error)
    } finally {
      setLoading(false)
    }
  }

  const activePurchases = purchases.filter((p) => p.active && (!p.expiresAt || new Date(p.expiresAt) > new Date()))
  const expiredPurchases = purchases.filter((p) => p.expiresAt && new Date(p.expiresAt) <= new Date())

  if (!session) return null

  return (
    <div className="min-h-[calc(100vh-16rem)] py-12">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
            <div>
              <h1 className="text-3xl font-bold text-white">Dashboard</h1>
              <p className="text-polaris-400">Manage your account, purchases, and ranks</p>
            </div>
            <div className="flex items-center gap-4">
              <Badge variant={getRoleBadgeVariant(session.user.role)} className="gap-1">
                <Shield className="h-3 w-3" />
                {session.user.role}
              </Badge>
            </div>
          </div>

          <div className="grid lg:grid-cols-4 gap-6 mb-8">
            <Card className="lg:col-span-3 bg-polaris-950/50 border-polaris-800">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="h-5 w-5 text-polaris-400" />
                  Profile
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs text-polaris-500 uppercase tracking-wider">Minecraft Username</label>
                    <p className="text-white font-medium">{session.user.minecraftUsername}</p>
                  </div>
                  <div>
                    <label className="text-xs text-polaris-500 uppercase tracking-wider">Email</label>
                    <p className="text-white font-medium">{session.user.email}</p>
                  </div>
                  <div>
                    <label className="text-xs text-polaris-500 uppercase tracking-wider">Role</label>
                    <Badge variant={getRoleBadgeVariant(session.user.role)} className="gap-1">
                      <Shield className="h-3 w-3" />
                      {session.user.role}
                    </Badge>
                  </div>
                  <div>
                    <label className="text-xs text-polaris-500 uppercase tracking-wider">Member Since</label>
                    <p className="text-white font-medium">Account created</p>
                  </div>
                </div>
                <Separator />
                <div className="flex items-center justify-between">
                  <p className="text-polaris-300">Email Verification</p>
                  <Badge variant={session.user.emailVerified ? 'success' : 'destructive'}>
                    {session.user.emailVerified ? 'Verified' : 'Pending'}
                  </Badge>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-polaris-950/50 border-polaris-800">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Crown className="h-5 w-5 text-polaris-400" />
                  Active Ranks
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {activePurchases.length === 0 ? (
                  <p className="text-polaris-500 text-center py-4">No active ranks</p>
                ) : (
                  activePurchases.map((purchase) => (
                    <div key={purchase.id} className="flex items-center gap-3 p-3 bg-polaris-900/50 rounded-lg border border-polaris-800">
                      <div className="p-2 rounded-lg bg-polaris-800/50">
                        <Crown className="h-5 w-5 text-polaris-400" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-white truncate">{purchase.product.name}</p>
                        <p className="text-xs text-polaris-400">
                          {purchase.expiresAt ? `Expires ${formatDateTime(purchase.expiresAt)}` : 'Permanent'}
                        </p>
                      </div>
                    </div>
                  ))
                )}
              </CardContent>
            </Card>
          </div>

          <Tabs defaultValue="purchases" className="space-y-6">
            <TabsList>
              <TabsTrigger value="purchases">Ranks & Items ({purchases.length})</TabsTrigger>
              <TabsTrigger value="orders">Order History ({orders.length})</TabsTrigger>
            </TabsList>

            <TabsContent value="purchases">
              {loading ? (
                <div className="space-y-4">
                  {[...Array(3)].map((_, i) => (
                    <Card key={i} className="animate-pulse bg-polaris-950/50 border-polaris-800">
                      <CardContent className="p-6">
                        <div className="flex gap-4">
                          <div className="h-12 w-12 bg-polaris-800 rounded-lg" />
                          <div className="flex-1 space-y-2">
                            <div className="h-4 bg-polaris-800 rounded w-1/4" />
                            <div className="h-3 bg-polaris-800 rounded w-1/2" />
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : purchases.length === 0 ? (
                <Card className="bg-polaris-950/50 border-polaris-800">
                  <CardContent className="py-12 text-center">
                    <Package className="mx-auto h-12 w-12 text-polaris-500 mb-4" />
                    <h3 className="text-lg font-medium text-white mb-2">No purchases yet</h3>
                    <p className="text-polaris-400 mb-4">Visit the store to get ranks and cosmetics</p>
                    <Link href="/store">
                      <Button className="gap-2">
                        <ArrowRight className="h-4 w-4" />
                        Browse Store
                      </Button>
                    </Link>
                  </CardContent>
                </Card>
              ) : (
                <div className="space-y-4">
                  {activePurchases.length > 0 && (
                    <>
                      <h3 className="text-lg font-semibold text-white">Active</h3>
                      <div className="space-y-3">
                        {activePurchases.map((purchase) => (
                          <Card key={purchase.id} className="bg-polaris-950/50 border-polaris-800">
                            <CardContent className="p-4">
                              <div className="flex items-center justify-between">
                                <div className="flex items-center gap-4">
                                  <div className="p-3 rounded-xl bg-polaris-800/50">
                                    <Crown className="h-6 w-6 text-polaris-400" />
                                  </div>
                                  <div>
                                    <p className="font-medium text-white">{purchase.product.name}</p>
                                    <p className="text-sm text-polaris-400">
                                      Granted {formatDateTime(purchase.grantedAt)}
                                      {purchase.expiresAt && ` • Expires ${formatDateTime(purchase.expiresAt)}`}
                                    </p>
                                  </div>
                                </div>
                                <Badge variant="success">Active</Badge>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    </>
                  )}
                  {expiredPurchases.length > 0 && (
                    <>
                      <h3 className="text-lg font-semibold text-white">Expired</h3>
                      <div className="space-y-3">
                        {expiredPurchases.map((purchase) => (
                          <Card key={purchase.id} className="bg-polaris-950/50 border-polaris-800 opacity-70">
                            <CardContent className="p-4">
                              <div className="flex items-center justify-between">
                                <div className="flex items-center gap-4">
                                  <div className="p-3 rounded-xl bg-polaris-800/50">
                                    <Crown className="h-6 w-6 text-polaris-500" />
                                  </div>
                                  <div>
                                    <p className="font-medium text-white">{purchase.product.name}</p>
                                    <p className="text-sm text-polaris-400">Expired {formatDateTime(purchase.expiresAt!)}</p>
                                  </div>
                                </div>
                                <Badge variant="outline">Expired</Badge>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    </>
                  )}
                </div>
              )}
            </TabsContent>

            <TabsContent value="orders">
              {loading ? (
                <div className="space-y-4">
                  {[...Array(3)].map((_, i) => (
                    <Card key={i} className="animate-pulse bg-polaris-950/50 border-polaris-800">
                      <CardContent className="p-6">
                        <div className="flex justify-between">
                          <div className="h-4 bg-polaris-800 rounded w-1/4" />
                          <div className="h-4 bg-polaris-800 rounded w-1/6" />
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : orders.length === 0 ? (
                <Card className="bg-polaris-950/50 border-polaris-800">
                  <CardContent className="py-12 text-center">
                    <History className="mx-auto h-12 w-12 text-polaris-500 mb-4" />
                    <h3 className="text-lg font-medium text-white mb-2">No orders yet</h3>
                    <p className="text-polaris-400 mb-4">Your purchase history will appear here</p>
                    <Link href="/store">
                      <Button className="gap-2">
                        <ArrowRight className="h-4 w-4" />
                        Browse Store
                      </Button>
                    </Link>
                  </CardContent>
                </Card>
              ) : (
                <div className="space-y-4">
                  {orders.map((order) => (
                    <Card key={order.id} className="bg-polaris-950/50 border-polaris-800">
                      <CardContent className="p-4">
                        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-4">
                          <div>
                            <p className="font-mono text-sm text-polaris-400">Order #{order.id.slice(0, 8)}</p>
                            <p className="text-xs text-polaris-500">{formatDateTime(order.createdAt)}</p>
                          </div>
                          <div className="flex items-center gap-3">
                            <Badge variant={
                              order.status === 'COMPLETED' ? 'success' :
                              order.status === 'PENDING' ? 'outline' :
                              order.status === 'FAILED' ? 'destructive' : 'default'
                            }>
                              {order.status}
                            </Badge>
                            <span className="text-xl font-bold text-white">{formatPrice(order.total)}</span>
                          </div>
                        </div>
                        <div className="grid sm:grid-cols-2 gap-2 text-sm">
                          {order.items.map((item, i) => (
                            <div key={i} className="flex justify-between text-polaris-300">
                              <span>{item.product.name} × {item.quantity}</span>
                              <span>{formatPrice(item.price * item.quantity)}</span>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}