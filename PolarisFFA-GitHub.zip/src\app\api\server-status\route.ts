import { NextResponse } from 'next/server'
import { getServerStatus } from '@/lib/server-status'

export async function GET() {
  try {
    const status = await getServerStatus()
    return NextResponse.json(status)
  } catch (error) {
    console.error('Server status API error:', error)
    return NextResponse.json(
      { online: false, playersOnline: 0, playersMax: 0, error: 'Failed to fetch status' },
      { status: 500 }
    )
  }
}