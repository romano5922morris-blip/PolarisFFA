'use client'

import { useEffect, useState } from 'react'
import { Server, Users, Wifi, CheckCircle, XCircle, Loader2 } from 'lucide-react'
import { cn } from '@/lib/utils'

interface ServerStatusData {
  online: boolean
  playersOnline: number
  playersMax: number
  version?: string
  motd?: string
  latency?: number
  error?: string
}

export function ServerStatus() {
  const [status, setStatus] = useState<ServerStatusData | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchStatus = async () => {
      try {
        const res = await fetch('/api/server-status')
        const data = await res.json()
        setStatus(data)
      } catch (error) {
        setStatus({ online: false, playersOnline: 0, playersMax: 0, error: 'Failed to fetch' })
      } finally {
        setLoading(false)
      }
    }

    fetchStatus()
    const interval = setInterval(fetchStatus, 30000)
    return () => clearInterval(interval)
  }, [])

  if (loading || !status) {
    return (
      <section className="py-12 bg-polaris-900/30 border-y border-polaris-800/50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 max-w-4xl mx-auto">
            {[1, 2, 3].map((i) => (
              <div key={i} className="p-6 rounded-xl bg-polaris-950/50 border border-polaris-800 animate-pulse">
                <div className="h-4 w-1/3 bg-polaris-800 rounded mb-4" />
                <div className="h-8 w-1/2 bg-polaris-800 rounded" />
              </div>
            ))}
          </div>
        </div>
      </section>
    )
  }

  const statusColor = status.online ? 'text-green-400' : 'text-red-400'
  const statusBg = status.online ? 'bg-green-900/20 border-green-800' : 'bg-red-900/20 border-red-800'
  const StatusIcon = status.online ? CheckCircle : XCircle

  return (
    <section className="py-12 bg-polaris-900/30 border-y border-polaris-800/50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <div className={cn('grid grid-cols-1 md:grid-cols-3 gap-4', statusBg, 'rounded-xl border p-6')}>
            <div className="flex items-center gap-4 p-4 rounded-lg bg-polaris-950/50">
              <div className={cn('p-3 rounded-lg', status.online ? 'bg-green-900/30' : 'bg-red-900/30')}>
                <StatusIcon className={cn('h-6 w-6', statusColor)} aria-hidden="true" />
              </div>
              <div>
                <p className="text-xs text-polaris-500 uppercase tracking-wider">Server Status</p>
                <p className={cn('text-lg font-semibold', statusColor)}>
                  {status.online ? 'Online' : 'Offline'}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-4 p-4 rounded-lg bg-polaris-950/50">
              <div className="p-3 rounded-lg bg-polaris-800/50">
                <Users className="h-6 w-6 text-polaris-400" aria-hidden="true" />
              </div>
              <div>
                <p className="text-xs text-polaris-500 uppercase tracking-wider">Players Online</p>
                <p className="text-lg font-semibold text-white">
                  {status.playersOnline} / {status.playersMax}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-4 p-4 rounded-lg bg-polaris-950/50">
              <div className="p-3 rounded-lg bg-polaris-800/50">
                <Wifi className="h-6 w-6 text-polaris-400" aria-hidden="true" />
              </div>
              <div>
                <p className="text-xs text-polaris-500 uppercase tracking-wider">Ping</p>
                <p className="text-lg font-semibold text-white">
                  {status.latency ? `${status.latency}ms` : 'N/A'}
                </p>
              </div>
            </div>

            {status.version && (
              <div className="md:col-span-3 flex items-center gap-4 p-4 rounded-lg bg-polaris-950/50">
                <div className="p-3 rounded-lg bg-polaris-800/50">
                  <Server className="h-6 w-6 text-polaris-400" aria-hidden="true" />
                </div>
                <div>
                  <p className="text-xs text-polaris-500 uppercase tracking-wider">Version</p>
                  <p className="text-lg font-semibold text-white font-mono">{status.version}</p>
                </div>
                {status.motd && (
                  <p className="flex-1 text-polaris-400 text-sm italic max-w-md truncate">{status.motd}</p>
                )}
              </div>
            )}

            {status.error && (
              <div className="md:col-span-3 p-4 rounded-lg bg-red-900/20 border border-red-800">
                <p className="text-red-400 text-sm flex items-center gap-2">
                  <XCircle className="h-4 w-4" aria-hidden="true" />
                  {status.error}
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  )
}