'use client'

import { useEffect, useState } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Loader2, Mail, CheckCircle, AlertCircle, RotateCcw } from 'lucide-react'
import { toast } from '@/hooks/use-toast'

export default function VerifyEmailPage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const token = searchParams.get('token')
  const email = searchParams.get('email')
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle')
  const [errorMessage, setErrorMessage] = useState('')

  useEffect(() => {
    if (token) {
      verifyEmail(token)
    }
  }, [token])

  const verifyEmail = async (verificationToken: string) => {
    setStatus('loading')
    try {
      const res = await fetch('/api/auth/verify-email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token: verificationToken }),
      })

      const data = await res.json()

      if (!res.ok) {
        setStatus('error')
        setErrorMessage(data.error || 'Verification failed. Please try again.')
        return
      }

      setStatus('success')
      toast({
        title: 'Email verified!',
        description: 'Your account has been verified. You can now log in.',
      })
    } catch (error) {
      setStatus('error')
      setErrorMessage('An unexpected error occurred. Please try again.')
    }
  }

  const resendVerification = async () => {
    if (!email) return
    setStatus('loading')
    try {
      const res = await fetch('/api/auth/resend-verification', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
      })

      const data = await res.json()

      if (!res.ok) {
        toast({
          variant: 'destructive',
          title: 'Failed to resend',
          description: data.error || 'Please try again later.',
        })
        setStatus('error')
        return
      }

      toast({
        title: 'Verification email sent',
        description: 'Please check your inbox for the verification link.',
      })
    } catch (error) {
      toast({
        variant: 'destructive',
        title: 'Failed to resend',
        description: 'An unexpected error occurred.',
      })
    }
  }

  if (status === 'success') {
    return (
      <div className="min-h-[calc(100vh-16rem)] flex items-center justify-center py-12 px-4">
        <div className="w-full max-w-md text-center">
          <Card className="bg-polaris-950/50 border-polaris-800">
            <CardContent className="py-12">
              <div className="mx-auto mb-6 flex h-16 w-16 items-center justify-center rounded-full bg-green-900/30">
                <CheckCircle className="h-8 w-8 text-green-400" aria-hidden="true" />
              </div>
              <h1 className="text-2xl font-bold text-white mb-2">Email Verified!</h1>
              <p className="text-polaris-400 mb-8">Your account has been successfully verified. You can now sign in to your account.</p>
              <Link href="/login">
                <Button className="w-full">Sign In</Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  if (status === 'error') {
    const resendDisabled = false
    return (
      <div className="min-h-[calc(100vh-16rem)] flex items-center justify-center py-12 px-4">
        <div className="w-full max-w-md text-center">
          <Card className="bg-polaris-950/50 border-polaris-800">
            <CardContent className="py-12">
              <div className="mx-auto mb-6 flex h-16 w-16 items-center justify-center rounded-full bg-red-900/30">
                <AlertCircle className="h-8 w-8 text-red-400" aria-hidden="true" />
              </div>
              <h1 className="text-2xl font-bold text-white mb-2">Verification Failed</h1>
              <p className="text-polaris-400 mb-6">{errorMessage}</p>
              <div className="flex flex-col gap-3">
                <Link href="/login">
                  <Button variant="outline" className="w-full">Sign In</Button>
                </Link>
                {email && (
                  <Button variant="secondary" onClick={resendVerification} disabled={resendDisabled}>
                    <RotateCcw className="mr-2 h-4 w-4" />
                    Resend Email
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-[calc(100vh-16rem)] flex items-center justify-center py-12 px-4">
      <div className="w-full max-w-md text-center">
        <Card className="bg-polaris-950/50 border-polaris-800">
          <CardContent className="py-12">
            <div className="mx-auto mb-6 flex h-16 w-16 items-center justify-center rounded-full bg-polaris-900/50 border border-polaris-800">
              <Loader2 className="h-8 w-8 text-polaris-400 animate-spin" aria-hidden="true" />
            </div>
            <h1 className="text-2xl font-bold text-white mb-2">Verifying Email</h1>
            <p className="text-polaris-400">Please wait while we verify your email address...</p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}