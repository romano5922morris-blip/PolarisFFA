import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'

export default function TestPage() {
  return (
    <div className="min-h-[calc(100vh-16rem)] py-12">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-4xl font-bold text-white mb-4">Test Page</h1>
          <p className="text-polaris-400 text-lg mb-8">This is a test page without use client</p>
          <Button>Test Button</Button>
        </div>
      </div>
    </div>
  )
}