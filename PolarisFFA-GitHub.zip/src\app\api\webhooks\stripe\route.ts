import { NextRequest, NextResponse } from 'next/server'
import { headers } from 'next/headers'
import { stripe } from '@/lib/stripe'
import prisma from '@/lib/prisma'

export async function POST(request: NextRequest) {
  try {
    const body = await request.text()
    const headersList = headers()
    const signature = headersList.get('stripe-signature')

    if (!signature) {
      return NextResponse.json({ error: 'Missing signature' }, { status: 400 })
    }

    let event

    try {
      event = stripe.webhooks.constructEvent(
        body,
        signature,
        process.env.STRIPE_WEBHOOK_SECRET!
      )
    } catch (err) {
      console.error('Webhook signature verification failed:', err)
      return NextResponse.json({ error: 'Invalid signature' }, { status: 400 })
    }

    if (event.type === 'checkout.session.completed') {
      const session = event.data.object

      const order = await prisma.order.findFirst({
        where: { paymentReference: session.id },
        include: { items: true },
      })

      if (!order) {
        console.error('Order not found for session:', session.id)
        return NextResponse.json({ error: 'Order not found' }, { status: 404 })
      }

      await prisma.$transaction(async (tx) => {
        await tx.order.update({
          where: { id: order.id },
          data: { status: 'COMPLETED' },
        })

        for (const item of order.items) {
          await tx.userRank.upsert({
            where: { userId_productId: { userId: order.userId, productId: item.productId } },
            create: {
              userId: order.userId,
              productId: item.productId,
              grantedAt: new Date(),
              active: true,
            },
            update: {
              active: true,
              grantedAt: new Date(),
            },
          })
        }

        await tx.staffLog.create({
          data: {
            staffUserId: order.userId,
            action: 'PURCHASE_COMPLETED',
            targetUserId: order.userId,
            metadata: { orderId: order.id, sessionId: session.id },
          },
        })
      })

      console.log(`Order ${order.id} completed for user ${order.userId}`)
    }

    if (event.type === 'checkout.session.expired') {
      const session = event.data.object

      await prisma.order.updateMany({
        where: { paymentReference: session.id, status: 'PENDING' },
        data: { status: 'EXPIRED' },
      })
    }

    return NextResponse.json({ received: true })
  } catch (error) {
    console.error('Webhook error:', error)
    return NextResponse.json({ error: 'Webhook handler failed' }, { status: 500 })
  }
}