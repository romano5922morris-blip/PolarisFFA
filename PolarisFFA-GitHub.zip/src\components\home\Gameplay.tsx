'use client'

import { Card, CardContent } from '@/components/ui/card'
import { Sword, Target, Gem, Users, Trophy, Flame } from 'lucide-react'
import { cn } from '@/lib/utils'

const gameplayModes = [
  {
    icon: Sword,
    title: 'Spear Combat',
    description: 'Master the art of spear warfare. Unique reach mechanics, charged attacks, and devastating combos.',
    features: ['Extended reach attacks', 'Charge mechanics', 'Combo system', 'Throwing spears'],
    color: 'from-amber-500 to-orange-600',
  },
  {
    icon: Target,
    title: 'Mace Combat',
    description: 'Crush your enemies with the heavy mace. High damage, knockback, and ground slam abilities.',
    features: ['Massive damage', 'Knockback physics', 'Ground slam AOE', 'Armor penetration'],
    color: 'from-stone-500 to-stone-700',
  },
  {
    icon: Gem,
    title: 'Diamond PvP',
    description: 'Classic diamond sword combat refined. Fast-paced, skill-based duels with custom mechanics.',
    features: ['Custom hit registry', 'Combo tracking', 'Sword abilities', 'Parry system'],
    color: 'from-cyan-400 to-blue-600',
  },
  {
    icon: Users,
    title: 'FFA Battles',
    description: 'Free-for-all chaos. Fight everyone, everywhere. Last player standing wins.',
    features: ['No teams allowed', 'Kill streaks', 'Bounty system', 'Leaderboards'],
    color: 'from-red-500 to-red-700',
  },
  {
    icon: Trophy,
    title: 'Ranked Seasons',
    description: 'Competitive seasons with exclusive rewards. Climb the ladder and prove your skill.',
    features: ['Seasonal ranks', 'Exclusive cosmetics', 'MMR system', 'Leaderboards'],
    color: 'from-yellow-400 to-amber-600',
  },
  {
    icon: Flame,
    title: 'Events & Tournaments',
    description: 'Regular events with unique rulesets and massive prize pools. Weekly tournaments.',
    features: ['Weekly tournaments', 'Special events', 'Custom modes', 'Real prizes'],
    color: 'from-orange-500 to-red-600',
  },
]

export function Gameplay() {
  return (
    <section className="section bg-polaris-900/30">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
            Combat & Gameplay
          </h2>
          <p className="text-polaris-400 text-lg">
            Three distinct combat styles, endless possibilities. Master them all.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
          {gameplayModes.map((mode, index) => (
            <Card key={index} className="group overflow-hidden bg-polaris-950/50 border-polaris-800 hover:border-polaris-700 transition-all duration-300">
              <div className={cn('h-1 bg-gradient-to-r', mode.color)} />
              <CardContent className="p-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className={cn('p-3 rounded-xl', `bg-gradient-to-br ${mode.color}`)}>
                    <mode.icon className="h-6 w-6 text-white" aria-hidden="true" />
                  </div>
                  <h3 className="text-xl font-bold text-white">{mode.title}</h3>
                </div>
                <p className="text-polaris-400 mb-4">{mode.description}</p>
                <ul className="space-y-2">
                  {mode.features.map((feature, i) => (
                    <li key={i} className="flex items-center gap-2 text-polaris-300 text-sm">
                      <span className="h-1.5 w-1.5 rounded-full bg-polaris-500" aria-hidden="true" />
                      {feature}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}