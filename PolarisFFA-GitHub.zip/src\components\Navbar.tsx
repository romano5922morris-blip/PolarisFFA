'use client'

import Link from 'next/link'
import { useSession, signOut } from 'next-auth/react'
import { Button } from '@/components/ui/button'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from '@/components/ui/dropdown-menu'
import { Separator } from '@/components/ui/separator'
import { cn } from '@/lib/utils'
import { Menu, X, LogOut, User, Settings, Shield, Crown, HelpCircle, Copy, Check } from 'lucide-react'
import { useState, useEffect } from 'react'

export function Navbar() {
  const { data: session, status } = useSession()
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  const [copied, setCopied] = useState(false)

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20)
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  const copyIP = async () => {
    await navigator.clipboard.writeText('play.polarisffa.eu')
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const navLinks = [
    { href: '/', label: 'Home' },
    { href: '/server', label: 'Server' },
    { href: '/store', label: 'Store' },
    { href: '/ranks', label: 'Ranks' },
    { href: '/community', label: 'Community' },
    { href: '/support', label: 'Support' },
  ]

  const isStaff = session?.user?.role && ['HELPER', 'ADMIN', 'HEAD_ADMIN', 'CO_OWNER', 'OWNER'].includes(session.user.role)

  return (
    <header className={cn('fixed top-0 left-0 right-0 z-50 transition-all duration-300', scrolled && 'bg-polaris-950/95 backdrop-blur-md border-b border-polaris-800')}>
      <nav className="container mx-auto px-4 sm:px-6 lg:px-8" aria-label="Main navigation">
        <div className="flex h-16 items-center justify-between">
          <Link href="/" className="flex items-center space-x-2" aria-label="PolarisFFA Home">
            <div className="relative flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-to-br from-polaris-500 to-polaris-700">
              <svg className="h-6 w-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" />
              </svg>
              <div className="absolute -top-1 -right-1 h-3 w-3 rounded-full bg-yellow-400 border-2 border-polaris-950 animate-pulse" aria-hidden="true" />
            </div>
            <span className="text-xl font-bold tracking-tight text-white">PolarisFFA</span>
          </Link>

          <div className="hidden md:flex md:items-center md:space-x-1">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="px-3 py-2 rounded-lg text-sm font-medium text-polaris-300 transition-colors hover:text-white hover:bg-polaris-800/50"
              >
                {link.label}
              </Link>
            ))}
          </div>

          <div className="hidden md:flex md:items-center md:space-x-3">
            <Button variant="outline" size="sm" onClick={copyIP} className="gap-2">
              <Copy className="h-4 w-4" />
              <span>Copy IP</span>
              {copied && <Check className="h-4 w-4 text-green-400" />}
            </Button>

            <a
              href="https://discord.gg/HutBfhABcJ"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium text-polaris-300 transition-colors hover:text-white hover:bg-polaris-800/50"
            >
              <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.442.747-.694 1.113a18.8 18.8 0 0 0-5.453 0 13.53 13.53 0 0 0-.711-1.113.077.077 0 0 0-.079-.037A19.735 19.735 0 0 0 3.676 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.083.083 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028 14.09 14.09 0 0 0 1.226-1.994.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.007-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 0 7.303-2.122 8.93-5.199a.077.077 0 0 1 .077-.01c2.59 0 4.962 1.065 6.648 2.764a.076.076 0 0 1 .032.054 19.914 19.914 0 0 0 5.07-4.329.077.077 0 0 0-.029-.079zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.419-2.157 2.419zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.419-2.157 2.419z" />
              </svg>
            </a>

            {session ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="relative h-10 w-10 rounded-full">
                    <Avatar className="h-10 w-10">
                      <AvatarImage src={`https://mc-heads.net/avatar/${session.user.minecraftUsername}/100`} alt={session.user.minecraftUsername} />
                      <AvatarFallback>{session.user.minecraftUsername[0].toUpperCase()}</AvatarFallback>
                    </Avatar>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuLabel className="flex items-center gap-2">
                    <Avatar className="h-8 w-8">
                      <AvatarImage src={`https://mc-heads.net/avatar/${session.user.minecraftUsername}/100`} alt={session.user.minecraftUsername} />
                      <AvatarFallback>{session.user.minecraftUsername[0].toUpperCase()}</AvatarFallback>
                    </Avatar>
                    <div className="flex flex-col">
                      <span className="text-sm font-medium text-white">{session.user.minecraftUsername}</span>
                      <span className="text-xs text-polaris-400">{session.user.email}</span>
                    </div>
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <Link href="/dashboard" className="flex items-center gap-2 w-full">
                      <User className="h-4 w-4" />
                      Dashboard
                    </Link>
                  </DropdownMenuItem>
                  {isStaff && (
                    <>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem asChild>
                        <Link href="/admin" className="flex items-center gap-2 w-full text-polaris-400">
                          <Shield className="h-4 w-4" />
                          Admin Panel
                        </Link>
                      </DropdownMenuItem>
                    </>
                  )}
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => signOut({ callbackUrl: '/' })} className="flex items-center gap-2 text-red-400">
                    <LogOut className="h-4 w-4" />
                    Logout
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <div className="flex items-center gap-2">
                <Link href="/login">
                  <Button variant="ghost" size="sm">Login</Button>
                </Link>
                <Link href="/register">
                  <Button size="sm" className="bg-gradient-to-r from-polaris-600 to-polaris-400 hover:from-polaris-500 hover:to-polaris-300">
                    Register
                  </Button>
                </Link>
              </div>
            )}
          </div>

          <button
            className="md:hidden p-2 rounded-lg text-polaris-300 hover:bg-polaris-800/50"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            aria-expanded={mobileMenuOpen}
            aria-controls="mobile-menu"
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        <div id="mobile-menu" className={cn('md:hidden overflow-hidden transition-all duration-300', mobileMenuOpen ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0')}>
          <div className="py-4 space-y-2 border-t border-polaris-800">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="block px-3 py-2 rounded-lg text-base font-medium text-polaris-300 hover:text-white hover:bg-polaris-800/50"
                onClick={() => setMobileMenuOpen(false)}
              >
                {link.label}
              </Link>
            ))}
            <Separator className="my-4" />
            <div className="px-3 space-y-2">
              <Button variant="outline" className="w-full justify-start gap-2" onClick={copyIP}>
                <Copy className="h-4 w-4" />
                <span>Copy IP: play.polarisffa.eu</span>
                {copied && <Check className="h-4 w-4 text-green-400" />}
              </Button>
              <a
                href="https://discord.gg/HutBfhABcJ"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 px-3 py-2 rounded-lg text-base font-medium text-polaris-300 hover:text-white hover:bg-polaris-800/50"
              >
                <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.442.747-.694 1.113a18.8 18.8 0 0 0-5.453 0 13.53 13.53 0 0 0-.711-1.113.077.077 0 0 0-.079-.037A19.735 19.735 0 0 0 3.676 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.083.083 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028 14.09 14.09 0 0 0 1.226-1.994.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.007-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 0 7.303-2.122 8.93-5.199a.077.077 0 0 1 .077-.01c2.59 0 4.962 1.065 6.648 2.764a.076.076 0 0 1 .032.054 19.914 19.914 0 0 0 5.07-4.329.077.077 0 0 0-.029-.079zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.419-2.157 2.419zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.419-2.157 2.419z" />
                </svg>
                Discord
              </a>
            </div>
            {session ? (
              <div className="px-3 pt-4 space-y-2 border-t border-polaris-800">
                <Link href="/dashboard" className="block px-3 py-2 rounded-lg text-base font-medium text-polaris-300 hover:text-white hover:bg-polaris-800/50" onClick={() => setMobileMenuOpen(false)}>
                  Dashboard
                </Link>
                {isStaff && (
                  <Link href="/admin" className="block px-3 py-2 rounded-lg text-base font-medium text-polaris-400 hover:text-white hover:bg-polaris-800/50" onClick={() => setMobileMenuOpen(false)}>
                    Admin Panel
                  </Link>
                )}
                <Button variant="outline" className="w-full justify-start" onClick={() => signOut({ callbackUrl: '/' })}>
                  <LogOut className="mr-2 h-4 w-4" />
                  Logout
                </Button>
              </div>
            ) : (
              <div className="px-3 pt-4 space-y-2 border-t border-polaris-800">
                <Link href="/login" className="block px-3 py-2 rounded-lg text-base font-medium text-polaris-300 hover:text-white hover:bg-polaris-800/50" onClick={() => setMobileMenuOpen(false)}>
                  Login
                </Link>
                <Link href="/register">
                  <Button className="w-full justify-start" onClick={() => setMobileMenuOpen(false)}>
                    Register
                  </Button>
                </Link>
              </div>
            )}
          </div>
        </div>
      </nav>
    </header>
  )
}