'use client'

import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Users, MessageSquare, Trophy, Heart, Star, Calendar, Video, ArrowRight, Clock, TrendingUp } from 'lucide-react'
import { formatDateTime } from '@/lib/utils'

const DiscordIcon = () => (
  <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
    <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.442.747-.694 1.113a18.8 18.8 0 0 0-5.453 0 13.53 13.53 0 0 0-.711-1.113.077.077 0 0 0-.079-.037A19.735 19.735 0 0 0 3.676 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.083.083 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028 14.09 14.09 0 0 0 1.226-1.994.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.007-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 0 7.303-2.122 8.93-5.199a.077.077 0 0 1 .077-.01c2.59 0 4.962 1.065 6.648 2.764a.076.076 0 0 1 .032.054 19.914 19.914 0 0 0 5.07-4.329.077.077 0 0 0-.029-.079zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.419-2.157 2.419zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.419-2.157 2.419z" />
  </svg>
)

const communityStats = [
  { icon: Users, value: '10,000+', label: 'Registered Players', color: 'text-polaris-400' },
  { icon: MessageSquare, value: '5,000+', label: 'Discord Members', color: 'text-purple-400' },
  { icon: Trophy, value: '50+', label: 'Tournaments Hosted', color: 'text-yellow-400' },
  { icon: Heart, value: '99.9%', label: 'Uptime Guarantee', color: 'text-red-400' },
]

const socialLinks = [
  {
    icon: DiscordIcon,
    title: 'Discord Community',
    description: 'Join 5,000+ players for chat, support, trading, events, and finding teammates.',
    members: '5,000+ members',
    link: 'https://discord.gg/HutBfhABcJ',
    color: 'from-purple-600 to-purple-500',
    badge: 'Most Active',
  },
  {
    icon: Video,
    title: 'YouTube Channel',
    description: 'Tutorials, tournament highlights, guides, and epic gameplay moments.',
    members: '10,000+ subscribers',
    link: 'https://www.youtube.com/@PolarisFFA',
    color: 'from-red-600 to-red-500',
    badge: 'Subscribe',
  },
]

const upcomingEvents = [
  { name: 'Weekly FFA Tournament', date: 'Every Saturday 3:00 PM UTC', prize: '$50 Prize Pool', type: 'Tournament' },
  { name: 'Spear Combat Workshop', date: 'Every Wednesday 7:00 PM UTC', prize: 'Free Entry', type: 'Workshop' },
  { name: 'Monthly Championship', date: 'First Sunday of Month', prize: '$200 Prize Pool', type: 'Championship' },
  { name: 'Community Build Contest', date: 'Monthly (Announced in Discord)', prize: 'Exclusive Cosmetics', type: 'Event' },
]

const leaderboard = [
  { rank: 1, username: 'PolarisChampion', elo: 2847, wins: 1247, rankName: 'POLARIS' },
  { rank: 2, username: 'SpearMaster', elo: 2723, wins: 1189, rankName: 'ELITE' },
  { rank: 3, username: 'MaceCrusher', elo: 2651, wins: 1134, rankName: 'ELITE' },
  { rank: 4, username: 'DiamondDuelist', elo: 2598, wins: 1092, rankName: 'MVP' },
  { rank: 5, username: 'FFAKing', elo: 2543, wins: 1056, rankName: 'MVP' },
]

export default function CommunityPage() {
  return (
    <div className="min-h-[calc(100vh-16rem)]">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h1 className="text-4xl sm:text-5xl font-bold text-white mb-4">Community</h1>
            <p className="text-polaris-400 text-lg max-w-2xl mx-auto">
              Connect with thousands of players, compete in events, and be part of the PolarisFFA family.
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-12">
            {communityStats.map((stat, index) => (
              <Card key={index} className="text-center bg-polaris-900/50 border-polaris-800">
                <CardContent className="py-6">
                  <div className="flex items-center justify-center gap-2 mb-2">
                    <div className="p-2 rounded-lg bg-polaris-800/50">
                      <stat.icon className={cn('h-6 w-6', stat.color)} />
                    </div>
                  </div>
                  <div className="text-3xl sm:text-4xl font-bold text-white">{stat.value}</div>
                  <div className="text-polaris-400 text-sm">{stat.label}</div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="grid lg:grid-cols-2 gap-8 mb-12">
            {socialLinks.map((social, index) => (
              <Card key={index} className="relative overflow-hidden bg-polaris-900/50 border-polaris-800">
                <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r" style={{ background: social.color }} />
                <CardContent className="p-6">
                  <div className="flex items-start gap-4 mb-4">
                    <div className={cn('p-4 rounded-2xl flex-shrink-0', `bg-gradient-to-br ${social.color}`)}>
                      <social.icon className="h-8 w-8 text-white" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <h3 className="text-xl font-bold text-white">{social.title}</h3>
                        <Badge variant="premium">{social.badge}</Badge>
                      </div>
                      <p className="text-polaris-300 mb-2">{social.description}</p>
                      <p className="text-polaris-500 text-sm">{social.members}</p>
                    </div>
                  </div>
                  <a href={social.link} target="_blank" rel="noopener noreferrer">
                    <Button className="w-full gap-2" style={{ background: social.color }}>
                      Join Now
                      <ArrowRight className="h-4 w-4" />
                    </Button>
                  </a>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="grid lg:grid-cols-2 gap-8 mb-12">
            <Card className="bg-polaris-900/50 border-polaris-800">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calendar className="h-5 w-5 text-polaris-400" />
                  Upcoming Events
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {upcomingEvents.map((event, index) => (
                    <div key={index} className="p-4 rounded-lg bg-polaris-950/50 border border-polaris-800">
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <h4 className="font-semibold text-white">{event.name}</h4>
                            <Badge variant="outline" className="text-xs">{event.type}</Badge>
                          </div>
                          <div className="flex items-center gap-4 text-sm text-polaris-400">
                            <span className="flex items-center gap-1">
                              <Clock className="h-3.5 w-3.5" />
                              {event.date}
                            </span>
                            <span className="flex items-center gap-1">
                              <TrendingUp className="h-3.5 w-3.5" />
                              {event.prize}
                            </span>
                          </div>
                        </div>
                        <Button variant="outline" size="sm">Join</Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="bg-polaris-900/50 border-polaris-800">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Trophy className="h-5 w-5 text-yellow-400" />
                  Top Players (This Season)
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {leaderboard.map((player) => (
                    <div key={player.rank} className="flex items-center gap-4 p-3 rounded-lg bg-polaris-950/50 border border-polaris-800">
                      <div className={cn('w-10 text-center font-bold text-xl', player.rank <= 3 ? 'text-yellow-400' : 'text-polaris-400')}>
                        #{player.rank}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="font-medium text-white truncate">{player.username}</span>
                          <Badge variant="outline" className="text-xs">{player.rankName}</Badge>
                        </div>
                        <div className="text-xs text-polaris-400 flex gap-4">
                          <span>{player.elo} ELO</span>
                          <span>{player.wins} Wins</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            <Card className="bg-polaris-900/50 border-polaris-800">
              <CardContent className="p-6 text-center">
                <Star className="mx-auto h-12 w-12 text-polaris-400 mb-4" />
                <h3 className="text-xl font-bold text-white mb-2">Create Content</h3>
                <p className="text-polaris-400 mb-4">Stream, record, or create content featuring PolarisFFA. Tag us for a chance to be featured!</p>
                <Button variant="outline" className="w-full">Learn More</Button>
              </CardContent>
            </Card>
            <Card className="bg-polaris-900/50 border-polaris-800">
              <CardContent className="p-6 text-center">
                <Users className="mx-auto h-12 w-12 text-polaris-400 mb-4" />
                <h3 className="text-xl font-bold text-white mb-2">Join Staff</h3>
                <p className="text-polaris-400 mb-4">We're always looking for dedicated helpers and moderators. Apply on Discord!</p>
                <Button variant="outline" className="w-full">Apply Now</Button>
              </CardContent>
            </Card>
            <Card className="bg-polaris-900/50 border-polaris-800">
              <CardContent className="p-6 text-center">
                <Heart className="mx-auto h-12 w-12 text-red-400 mb-4" />
                <h3 className="text-xl font-bold text-white mb-2">Support Us</h3>
                <p className="text-polaris-400 mb-4">Every purchase helps keep the server running and funds new features.</p>
                <a href="/store">
                  <Button className="w-full gap-2 bg-gradient-to-r from-polaris-600 to-polaris-400">
                    <ArrowRight className="h-4 w-4" />
                    View Store
                  </Button>
                </a>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}

function cn(...classes: (string | boolean | undefined)[]) {
  return classes.filter(Boolean).join(' ')
}