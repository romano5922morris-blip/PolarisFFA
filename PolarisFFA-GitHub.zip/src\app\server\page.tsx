import { Metadata } from 'next'
import { ServerInfo } from '@/components/server/ServerInfo'
import { GameplayModes } from '@/components/server/GameplayModes'
import { Features } from '@/components/server/Features'

export const metadata: Metadata = {
  title: 'Server Information',
  description: 'Learn about PolarisFFA - Minecraft FFA server with Spear, Mace & Diamond SMP combat',
}

export default function ServerPage() {
  return (
    <div className="min-h-[calc(100vh-16rem)]">
      <ServerInfo />
      <GameplayModes />
      <Features />
    </div>
  )
}