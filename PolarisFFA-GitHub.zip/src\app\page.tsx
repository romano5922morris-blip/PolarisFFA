import { Metadata } from 'next'
import { Hero } from '@/components/home/Hero'
import { ServerStatus } from '@/components/home/ServerStatus'
import { FeaturedRanks } from '@/components/home/FeaturedRanks'
import { WhyPolaris } from '@/components/home/WhyPolaris'
import { Gameplay } from '@/components/home/Gameplay'
import { Community } from '@/components/home/Community'
import { DiscordSection } from '@/components/home/DiscordSection'
import { YouTubeSection } from '@/components/home/YouTubeSection'

export const metadata: Metadata = {
  title: 'Minecraft FFA Server — Spear, Mace & Diamond SMP',
  description: 'Join PolarisFFA for the ultimate Minecraft FFA experience. Competitive Spear, Mace & Diamond PvP with progression systems. IP: play.polarisffa.eu',
}

export default function HomePage() {
  return (
    <div className="flex flex-col">
      <Hero />
      <ServerStatus />
      <FeaturedRanks />
      <WhyPolaris />
      <Gameplay />
      <Community />
      <DiscordSection />
      <YouTubeSection />
    </div>
  )
}