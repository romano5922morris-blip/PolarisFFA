'use client'

import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Sword, Target, Gem, Users, Trophy, Flame, Zap, Shield, Star } from 'lucide-react'

const modes = [
  {
    icon: Sword,
    title: 'Spear Combat',
    subtitle: 'Reach & Precision',
    description: 'Master the art of spear warfare with unique reach mechanics, charged attacks, and devastating combo chains.',
    features: [
      'Extended melee reach (4.5 blocks)',
      'Charge attack system (hold to power up)',
      'Combo chains with visual feedback',
      'Spear throwing with retrieval',
      'Impale effect on critical hits',
    ],
    color: 'from-amber-500 to-orange-600',
    badge: 'New',
  },
  {
    icon: Target,
    title: 'Mace Combat',
    subtitle: 'Heavy Impact',
    description: 'Crush your enemies with the devastating mace. High damage, knockback physics, and ground-shaking abilities.',
    features: [
      'Massive single-target damage',
      'Knockback physics system',
      'Ground slam AOE attack',
      'Armor penetration passive',
      'Stun chance on heavy hits',
    ],
    color: 'from-stone-500 to-stone-700',
    badge: 'Popular',
  },
  {
    icon: Gem,
    title: 'Diamond PvP',
    subtitle: 'Classic Refined',
    description: 'Classic diamond sword combat refined with custom mechanics. Fast-paced, skill-based duels.',
    features: [
      'Custom hit registration',
      'Combo counter tracking',
      'Sword special abilities',
      'Parry/riposte system',
      'Critical hit particles',
    ],
    color: 'from-cyan-400 to-blue-600',
    badge: 'Classic',
  },
  {
    icon: Users,
    title: 'Free-For-All',
    subtitle: 'Pure Chaos',
    description: 'No teams, no alliances. Everyone is your enemy. Last player standing claims victory.',
    features: [
      'Solo-only gameplay',
      'Kill streak rewards',
      'Bounty system for top players',
      'Real-time leaderboards',
      'Spectator mode after death',
    ],
    color: 'from-red-500 to-red-700',
    badge: 'Core',
  },
  {
    icon: Trophy,
    title: 'Ranked Seasons',
    subtitle: 'Competitive Ladder',
    description: 'Climb the competitive ladder through seasonal rankings. Exclusive rewards for top performers.',
    features: [
      'Seasonal MMR system',
      'Division tiers (Iron to Polaris)',
      'Exclusive seasonal cosmetics',
      'Weekly rank decay',
      'Leaderboard recognition',
    ],
    color: 'from-yellow-400 to-amber-600',
    badge: 'Seasonal',
  },
  {
    icon: Flame,
    title: 'Events & Tournaments',
    subtitle: 'Special Events',
    description: 'Regular events with unique rulesets, custom maps, and massive prize pools.',
    features: [
      'Weekly automated tournaments',
      'Monthly championship events',
      'Custom event maps',
      'Real-world prize pools',
      'Spectator streaming support',
    ],
    color: 'from-orange-500 to-red-600',
    badge: 'Weekly',
  },
]

export function GameplayModes() {
  return (
    <section className="py-16 sm:py-24 lg:py-32 bg-polaris-900/30 border-y border-polaris-800/50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl sm:text-5xl font-bold text-white mb-4">Combat & Gameplay Modes</h2>
            <p className="text-polaris-400 text-lg max-w-2xl mx-auto">
              Three distinct combat styles, endless possibilities. Master them all to become a Polaris champion.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {modes.map((mode, index) => (
              <Card key={index} className="group relative overflow-hidden bg-polaris-950/50 border-polaris-800 hover:border-polaris-700 transition-all duration-300 h-full">
                <div className={cn('absolute top-0 left-0 right-0 h-1', `bg-gradient-to-r ${mode.color}`)} />
                <CardContent className="p-6 sm:p-8">
                  <div className="flex items-start gap-4 mb-6">
                    <div className={cn('p-4 rounded-2xl flex-shrink-0', `bg-gradient-to-br ${mode.color}`)}>
                      <mode.icon className="h-8 w-8 text-white" aria-hidden="true" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="text-2xl font-bold text-white">{mode.title}</h3>
                        <Badge variant="outline" className="text-xs">{mode.badge}</Badge>
                      </div>
                      <p className="text-polaris-400 text-sm font-medium">{mode.subtitle}</p>
                    </div>
                  </div>
                  <p className="text-polaris-300 mb-6">{mode.description}</p>
                  <ul className="space-y-3">
                    {mode.features.map((feature, i) => (
                      <li key={i} className="flex items-start gap-3 text-polaris-300">
                        <div className={cn('flex-shrink-0 mt-0.5 h-2 w-2 rounded-full', `bg-gradient-to-r ${mode.color}`)} />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

function cn(...classes: (string | boolean | undefined)[]) {
  return classes.filter(Boolean).join(' ')
}