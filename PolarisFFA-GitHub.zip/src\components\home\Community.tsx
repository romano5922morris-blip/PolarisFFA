'use client'

import { Card, CardContent } from '@/components/ui/card'
import { Users, MessageSquare, Trophy, Heart, Star, Calendar } from 'lucide-react'
import Link from 'next/link'
import { Button } from '@/components/ui/button'

const communityStats = [
  { icon: Users, value: '10,000+', label: 'Registered Players' },
  { icon: MessageSquare, value: '5,000+', label: 'Discord Members' },
  { icon: Trophy, value: '50+', label: 'Tournaments Hosted' },
  { icon: Heart, value: '99%', label: 'Uptime Guarantee' },
]

const communityFeatures = [
  {
    icon: Star,
    title: 'Active Discord',
    description: 'Join our thriving community for announcements, support, trading, and finding teammates.',
    link: 'https://discord.gg/HutBfhABcJ',
    external: true,
  },
  {
    icon: Calendar,
    title: 'Weekly Events',
    description: 'Participate in weekly tournaments, special events, and seasonal competitions with prizes.',
    link: '/events',
    external: false,
  },
  {
    icon: Trophy,
    title: 'Leaderboards',
    description: 'Compete for top spots on global leaderboards. Earn exclusive rewards and recognition.',
    link: '/leaderboards',
    external: false,
  },
  {
    icon: MessageSquare,
    title: 'Player Support',
    description: 'Dedicated support team and helper staff available to assist with any issues.',
    link: '/support',
    external: false,
  },
]

export function Community() {
  return (
    <section className="section bg-polaris-950">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
            Join Our Community
          </h2>
          <p className="text-polaris-400 text-lg">
            Connect with thousands of players, compete in events, and make friends.
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-16 max-w-4xl mx-auto">
          {communityStats.map((stat, index) => (
            <Card key={index} className="text-center bg-polaris-900/50 border-polaris-800">
              <CardContent className="py-6">
                <div className="flex items-center justify-center gap-2 mb-2">
                  <div className="p-2 rounded-lg bg-polaris-800/50">
                    <stat.icon className="h-6 w-6 text-polaris-400" aria-hidden="true" />
                  </div>
                </div>
                <div className="text-3xl sm:text-4xl font-bold text-white">{stat.value}</div>
                <div className="text-polaris-400 text-sm">{stat.label}</div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
          {communityFeatures.map((feature, index) => (
            <Card key={index} className="group bg-polaris-900/50 border-polaris-800 hover:border-polaris-700 transition-all duration-300">
              <CardContent className="p-6">
                <div className="flex items-start gap-4">
                  <div className="p-3 rounded-xl bg-polaris-800/50 group-hover:bg-polaris-500/10 transition-colors flex-shrink-0">
                    <feature.icon className="h-6 w-6 text-polaris-400" aria-hidden="true" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold text-white mb-1">{feature.title}</h3>
                    <p className="text-polaris-400 text-sm mb-4">{feature.description}</p>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      asChild
                      className="group-hover:border-polaris-500 group-hover:text-polaris-300"
                    >
                      {feature.external ? (
                        <a href={feature.link} target="_blank" rel="noopener noreferrer">Join Now</a>
                      ) : (
                        <Link href={feature.link}>Learn More</Link>
                      )}
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}