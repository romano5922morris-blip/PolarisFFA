import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import prisma from '@/lib/prisma'

export async function GET() {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const purchases = await prisma.userRank.findMany({
      where: { userId: session.user.id },
      include: { product: true },
      orderBy: { grantedAt: 'desc' },
    })

    return NextResponse.json(purchases)
  } catch (error) {
    console.error('Failed to fetch purchases:', error)
    return NextResponse.json({ error: 'Failed to fetch purchases' }, { status: 500 })
  }
}