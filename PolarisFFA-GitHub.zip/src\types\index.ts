export type Role = 'USER' | 'HELPER' | 'ADMIN' | 'HEAD_ADMIN' | 'CO_OWNER' | 'OWNER'
export type OrderStatus = 'PENDING' | 'PROCESSING' | 'COMPLETED' | 'FAILED' | 'REFUNDED' | 'CANCELLED'
export type TicketCategory = 'PAYMENT' | 'ACCOUNT' | 'MINECRAFT' | 'BUG' | 'OTHER'
export type TicketStatus = 'OPEN' | 'IN_PROGRESS' | 'CLOSED'

export interface ProductWithRelations {
  id: string
  name: string
  description: string
  price: number
  type: string
  active: boolean
  featured: boolean
  sortOrder: number
  metadata: Record<string, unknown> | null
  createdAt: Date
  updatedAt: Date
}

export interface UserRankWithProduct {
  id: string
  userId: string
  productId: string
  grantedAt: Date
  expiresAt: Date | null
  active: boolean
  product: ProductWithRelations
}

export interface OrderWithItems {
  id: string
  userId: string
  status: OrderStatus
  total: number
  paymentProvider: string
  paymentReference: string | null
  metadata: Record<string, unknown> | null
  createdAt: Date
  updatedAt: Date
  items: Array<{
    id: string
    productId: string
    price: number
    quantity: number
    product: ProductWithRelations
  }>
}

export interface TicketWithMessages {
  id: string
  userId: string
  category: TicketCategory
  status: TicketStatus
  subject: string
  createdAt: Date
  updatedAt: Date
  messages: Array<{
    id: string
    userId: string
    message: string
    isStaff: boolean
    createdAt: Date
    user: {
      id: string
      minecraftUsername: string
      role: Role
    }
  }>
  user: {
    id: string
    email: string
    minecraftUsername: string
    role: Role
  }
}

export interface ServerStatusData {
  online: boolean
  playersOnline: number
  playersMax: number
  version?: string
  motd?: string
  latency?: number
  error?: string
}

export const ROLE_HIERARCHY: Record<Role, number> = {
  USER: 0,
  HELPER: 1,
  ADMIN: 2,
  HEAD_ADMIN: 3,
  CO_OWNER: 4,
  OWNER: 5,
}

export const ROLE_COLORS: Record<Role, string> = {
  USER: 'text-gray-400',
  HELPER: 'text-blue-400',
  ADMIN: 'text-green-400',
  HEAD_ADMIN: 'text-purple-400',
  CO_OWNER: 'text-orange-400',
  OWNER: 'text-red-400',
}

export const ROLE_BADGES: Record<Role, string> = {
  USER: 'bg-gray-800 text-gray-300',
  HELPER: 'bg-blue-900/50 text-blue-300 border-blue-800',
  ADMIN: 'bg-green-900/50 text-green-300 border-green-800',
  HEAD_ADMIN: 'bg-purple-900/50 text-purple-300 border-purple-800',
  CO_OWNER: 'bg-orange-900/50 text-orange-300 border-orange-800',
  OWNER: 'bg-red-900/50 text-red-300 border-red-800',
}