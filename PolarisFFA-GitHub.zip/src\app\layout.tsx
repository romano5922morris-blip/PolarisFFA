import type { Metadata, Viewport } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'
import { Providers } from '@/components/Providers'
import { Navbar } from '@/components/Navbar'
import { Footer } from '@/components/Footer'

const inter = Inter({ subsets: ['latin'], variable: '--font-inter' })

export const metadata: Metadata = {
  title: {
    default: 'PolarisFFA — Minecraft FFA Server',
    template: '%s | PolarisFFA',
  },
  description: 'PolarisFFA - Minecraft FFA Server featuring Spear, Mace & Diamond SMP combat. Join play.polarisffa.eu for competitive PvP and progression.',
  keywords: ['Minecraft', 'FFA', 'PvP', 'Server', 'Spear', 'Mace', 'Diamond', 'SMP', 'PolarisFFA'],
  authors: [{ name: 'PolarisFFA' }],
  creator: 'PolarisFFA',
  publisher: 'PolarisFFA',
  robots: 'index, follow',
  openGraph: {
    type: 'website',
    locale: 'en_US',
    url: 'https://polarisffa.eu',
    siteName: 'PolarisFFA',
    title: 'PolarisFFA — Minecraft FFA Server',
    description: 'Minecraft FFA Server featuring Spear, Mace & Diamond SMP combat. Join play.polarisffa.eu for competitive PvP.',
    images: [
      {
        url: '/og-image.png',
        width: 1200,
        height: 630,
        alt: 'PolarisFFA - Minecraft FFA Server',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'PolarisFFA — Minecraft FFA Server',
    description: 'Minecraft FFA Server featuring Spear, Mace & Diamond SMP combat.',
    images: ['/og-image.png'],
    creator: '@PolarisFFA',
  },
  verification: {
    google: 'google-site-verification-code',
  },
}

export const viewport: Viewport = {
  themeColor: [
    { media: '(prefers-color-scheme: light)', color: '#0c4a6e' },
    { media: '(prefers-color-scheme: dark)', color: '#020617' },
  ],
  width: 'device-width',
  initialScale: 1,
  maximumScale: 5,
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" className={`${inter.variable} dark`} suppressHydrationWarning>
      <head>
        <link rel="preconnect" href="https://api.mcsrvstat.us" />
        <link rel="dns-prefetch" href="https://api.mcsrvstat.us" />
      </head>
      <body className="min-h-screen bg-polaris-950 text-white antialiased font-sans">
        <Providers>
          <Navbar />
          <main id="main-content" className="pt-16 min-h-[calc(100vh-16rem)]">
            {children}
          </main>
          <Footer />
        </Providers>
      </body>
    </html>
  )
}