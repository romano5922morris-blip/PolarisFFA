import { type ClassValue, clsx } from 'clsx'
import { twMerge } from 'tailwind-merge'

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatPrice(priceInCents: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
  }).format(priceInCents / 100)
}

export function formatDate(date: Date | string): string {
  return new Intl.DateTimeFormat('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  }).format(new Date(date))
}

export function formatDateTime(date: Date | string): string {
  return new Intl.DateTimeFormat('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  }).format(new Date(date))
}

export function generateVerificationToken(): string {
  return Array.from(crypto.getRandomValues(new Uint8Array(32)))
    .map(b => b.toString(16).padStart(2, '0'))
    .join('')
}

export function getRoleHierarchy(role: string): number {
  const hierarchy: Record<string, number> = {
    USER: 0,
    HELPER: 1,
    ADMIN: 2,
    HEAD_ADMIN: 3,
    CO_OWNER: 4,
    OWNER: 5,
  }
  return hierarchy[role] ?? 0
}

export function canManageRole(actorRole: string, targetRole: string): boolean {
  return getRoleHierarchy(actorRole) > getRoleHierarchy(targetRole)
}

export function truncate(str: string, length: number): string {
  if (str.length <= length) return str
  return str.slice(0, length) + '...'
}

export const ROLE_HIERARCHY: Record<string, number> = {
  USER: 0,
  HELPER: 1,
  ADMIN: 2,
  HEAD_ADMIN: 3,
  CO_OWNER: 4,
  OWNER: 5,
}

export const ROLE_COLORS: Record<string, string> = {
  USER: 'text-gray-400',
  HELPER: 'text-blue-400',
  ADMIN: 'text-green-400',
  HEAD_ADMIN: 'text-purple-400',
  CO_OWNER: 'text-orange-400',
  OWNER: 'text-red-400',
}

export const ROLE_BADGES: Record<string, string> = {
  USER: 'bg-gray-800 text-gray-300',
  HELPER: 'bg-blue-900/50 text-blue-300 border-blue-800',
  ADMIN: 'bg-green-900/50 text-green-300 border-green-800',
  HEAD_ADMIN: 'bg-purple-900/50 text-purple-300 border-purple-800',
  CO_OWNER: 'bg-orange-900/50 text-orange-300 border-orange-800',
  OWNER: 'bg-red-900/50 text-red-300 border-red-800',
}