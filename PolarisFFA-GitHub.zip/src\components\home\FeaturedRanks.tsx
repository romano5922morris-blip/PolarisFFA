'use client'

import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Star, Crown, Gem, Sparkles, Shield, Sword } from 'lucide-react'
import { cn } from '@/lib/utils'

const featuredRanks = [
  {
    id: 'vip',
    name: 'VIP',
    price: 999, // $9.99
    description: 'Entry-level supporter rank with basic perks',
    color: 'from-yellow-500 to-orange-500',
    borderColor: 'border-yellow-500',
    glowColor: 'shadow-yellow-500/20',
    icon: Star,
    benefits: [
      'VIP prefix in chat',
      'Access to /vip kit',
      'Colored chat messages',
      '1 home (/sethome)',
      'Priority queue access',
      'Discord VIP role',
    ],
    featured: false,
  },
  {
    id: 'mvp',
    name: 'MVP',
    price: 1999, // $19.99
    description: 'Enhanced rank with gameplay advantages',
    color: 'from-polaris-400 to-polaris-600',
    borderColor: 'border-polaris-400',
    glowColor: 'shadow-polaris-500/30',
    icon: Crown,
    benefits: [
      'All VIP perks',
      'MVP prefix in chat',
      'Access to /mvp kit',
      '3 homes (/sethome)',
      '/fly in lobby',
      'Custom join messages',
      'Monthly crate key',
      'Discord MVP role',
    ],
    featured: true,
  },
  {
    id: 'elite',
    name: 'ELITE',
    price: 3999, // $39.99
    description: 'Premium rank with exclusive cosmetics',
    color: 'from-purple-500 to-pink-500',
    borderColor: 'border-purple-500',
    glowColor: 'shadow-purple-500/30',
    icon: Gem,
    benefits: [
      'All MVP perks',
      'ELITE prefix in chat',
      'Access to /elite kit',
      'Unlimited homes',
      '/fly everywhere',
      'Particle trails',
      'Custom kill messages',
      'Weekly crate keys',
      'Discord ELITE role',
      'Exclusive cosmetics',
    ],
    featured: false,
  },
]

export function FeaturedRanks() {
  return (
    <section className="section bg-polaris-900/30">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
              Featured Ranks
            </h2>
            <p className="text-polaris-400 text-lg max-w-2xl mx-auto">
              Support the server and unlock exclusive perks, cosmetics, and gameplay advantages.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {featuredRanks.map((rank) => (
              <Link key={rank.id} href={`/store?rank=${rank.id}`}>
                <Card className={cn(
                  'relative overflow-hidden transition-all duration-300 h-full',
                  'hover:border-polaris-700 hover:shadow-2xl',
                  rank.featured && 'border-polaris-500/50 shadow-polaris-500/10',
                  rank.glowColor
                )}>
                  {rank.featured && (
                    <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-polaris-400 to-polaris-600" />
                  )}
                  
                  <div className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div className={cn('p-3 rounded-xl', `bg-gradient-to-br ${rank.color}`, rank.glowColor)}>
                        <rank.icon className="h-8 w-8 text-white" aria-hidden="true" />
                      </div>
                      {rank.featured && (
                        <Badge variant="premium" className="text-xs">
                          <Sparkles className="h-3 w-3 mr-1" aria-hidden="true" />
                          Popular
                        </Badge>
                      )}
                    </div>

                    <h3 className="text-2xl font-bold text-white mb-2">{rank.name}</h3>
                    <p className="text-polaris-400 text-sm mb-4">{rank.description}</p>

                    <div className="mb-6">
                      <span className="text-4xl font-bold text-white">${(rank.price / 100).toFixed(2)}</span>
                      <span className="text-polaris-500 ml-2">one-time</span>
                    </div>

                    <ul className="space-y-3 mb-6">
                      {rank.benefits.map((benefit, index) => (
                        <li key={index} className="flex items-start gap-3 text-polaris-300 text-sm">
                          <CheckCircle className="h-5 w-5 text-polaris-400 flex-shrink-0 mt-0.5" aria-hidden="true" />
                          <span>{benefit}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <CardContent className="pt-0 pb-6 px-6">
                    <Button 
                      className={cn('w-full', rank.featured ? 'bg-gradient-to-r from-polaris-600 to-polaris-400 hover:from-polaris-500 hover:to-polaris-300' : '')}
                    >
                      Get {rank.name}
                    </Button>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>

          <div className="text-center mt-10">
            <Link href="/ranks">
              <Button variant="outline" size="lg" className="gap-2">
                View All Ranks
                <ArrowRight className="h-4 w-4" aria-hidden="true" />
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </section>
  )
}

function CheckCircle({ className, ...props }: React.SVGProps<SVGSVGElement>) {
  return (
    <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24" {...props}>
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
    </svg>
  )
}

function ArrowRight({ className, ...props }: React.SVGProps<SVGSVGElement>) {
  return (
    <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24" {...props}>
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
    </svg>
  )
}