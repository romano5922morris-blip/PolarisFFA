'use client'

import { useEffect, useState } from 'react'
import { Server, Users, Wifi, Globe, Shield, Zap, Copy, Check, Loader2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { toast } from '@/hooks/use-toast'

interface ServerStatus {
  online: boolean
  playersOnline: number
  playersMax: number
  version?: string
  motd?: string
  latency?: number
  error?: string
}

export function ServerInfo() {
  const [status, setStatus] = useState<ServerStatus | null>(null)
  const [loading, setLoading] = useState(true)
  const [copied, setCopied] = useState(false)

  useEffect(() => {
    fetchStatus()
    const interval = setInterval(fetchStatus, 30000)
    return () => clearInterval(interval)
  }, [])

  const fetchStatus = async () => {
    try {
      const res = await fetch('/api/server-status')
      const data = await res.json()
      setStatus(data)
    } catch (error) {
      setStatus({ online: false, playersOnline: 0, playersMax: 0, error: 'Failed to fetch' })
    } finally {
      setLoading(false)
    }
  }

  const copyIP = async () => {
    await navigator.clipboard.writeText('play.polarisffa.eu')
    setCopied(true)
    toast({ title: 'IP Copied!', description: 'play.polarisffa.eu copied to clipboard' })
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <section className="py-16 sm:py-24 lg:py-32 bg-polaris-950">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16">
            <h1 className="text-4xl sm:text-5xl font-bold text-white mb-4">Server Information</h1>
            <p className="text-polaris-400 text-lg max-w-2xl mx-auto">
              Everything you need to know about connecting to PolarisFFA
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-8 mb-16">
            <Card className="bg-polaris-900/50 border-polaris-800">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Server className="h-5 w-5 text-polaris-400" />
                  Connection Details
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="p-6 rounded-xl bg-polaris-950/50 border border-polaris-800">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <p className="text-xs text-polaris-500 uppercase tracking-wider">Server Address</p>
                      <code className="text-xl font-mono text-white break-all">play.polarisffa.eu</code>
                    </div>
                    <Button variant="outline" size="icon" onClick={copyIP} className={copied ? 'text-green-400 border-green-400' : ''}>
                      {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                    </Button>
                  </div>
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div>
                      <p className="text-xs text-polaris-500 uppercase tracking-wider">Port (Java)</p>
                      <p className="text-white font-medium">25565</p>
                    </div>
                    <div>
                      <p className="text-xs text-polaris-500 uppercase tracking-wider">Port (Bedrock)</p>
                      <p className="text-white font-medium">19132</p>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="p-4 rounded-lg bg-polaris-950/50 border border-polaris-800 text-center">
                    <Globe className="h-6 w-6 text-polaris-400 mx-auto mb-2" />
                    <p className="text-xs text-polaris-500 uppercase tracking-wider">Supported Versions</p>
                    <p className="text-white font-medium">1.20.x - Latest</p>
                  </div>
                  <div className="p-4 rounded-lg bg-polaris-950/50 border border-polaris-800 text-center">
                    <Shield className="h-6 w-6 text-polaris-400 mx-auto mb-2" />
                    <p className="text-xs text-polaris-500 uppercase tracking-wider">Protection</p>
                    <p className="text-white font-medium">Anti-Cheat Enabled</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-polaris-900/50 border-polaris-800">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5 text-polaris-400" />
                  Live Status
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {loading ? (
                  <div className="space-y-4">
                    {[1, 2, 3].map((i) => (
                      <div key={i} className="h-16 bg-polaris-800 rounded animate-pulse" />
                    ))}
                  </div>
                ) : status ? (
                  <div className="space-y-4">
                    <div className={cn('p-6 rounded-xl text-center', status.online ? 'bg-green-900/20 border border-green-800' : 'bg-red-900/20 border border-red-800')}>
                      <div className="flex items-center justify-center gap-3 mb-4">
                        {status.online ? (
                          <span className="relative flex h-3 w-3">
                            <span className="absolute inset-0 rounded-full bg-green-400 animate-ping opacity-75" />
                            <span className="relative rounded-full bg-green-400" />
                          </span>
                        ) : (
                          <span className="relative flex h-3 w-3 rounded-full bg-red-400" />
                        )}
                        <span className={cn('text-2xl font-bold', status.online ? 'text-green-400' : 'text-red-400')}>
                          {status.online ? 'Online' : 'Offline'}
                        </span>
                      </div>
                      {status.online && (
                        <div className="grid grid-cols-3 gap-4 text-center">
                          <div>
                            <p className="text-3xl font-bold text-white">{status.playersOnline}</p>
                            <p className="text-polaris-400 text-sm">Players Online</p>
                          </div>
                          <div>
                            <p className="text-3xl font-bold text-white">{status.playersMax}</p>
                            <p className="text-polaris-400 text-sm">Max Players</p>
                          </div>
                          <div>
                            <p className="text-3xl font-bold text-white">{status.latency ? `${status.latency}ms` : 'N/A'}</p>
                            <p className="text-polaris-400 text-sm">Ping</p>
                          </div>
                        </div>
                      )}
                      {status.version && (
                        <p className="text-polaris-300 mt-2">Version: <span className="font-mono text-white">{status.version}</span></p>
                      )}
                      {status.motd && (
                        <p className="text-polaris-400 text-sm italic mt-2 max-w-md mx-auto">{status.motd}</p>
                      )}
                    </div>

                    {status.online && (
                      <div className="grid grid-cols-2 gap-4">
                        <Button variant="outline" className="gap-2" onClick={copyIP}>
                          <Copy className="h-4 w-4" />
                          Copy IP
                        </Button>
                        <a href="/store">
                          <Button className="gap-2 bg-gradient-to-r from-polaris-600 to-polaris-400 hover:from-polaris-500 hover:to-polaris-300">
                            <Zap className="h-4 w-4" />
                            Play Now
                          </Button>
                        </a>
                      </div>
                    )}
                  </div>
                ) : null}
              </CardContent>
            </Card>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {[
              { icon: Server, title: 'Optimized Performance', desc: 'Enterprise hardware with custom optimizations for lag-free PvP' },
              { icon: Zap, title: 'Custom Combat Mechanics', desc: 'Unique Spear, Mace & Diamond PvP systems you won\'t find elsewhere' },
              { icon: Shield, title: 'Fair Play Guaranteed', desc: 'Advanced anti-cheat and active moderation for competitive integrity' },
            ].map((item, i) => (
              <Card key={i} className="bg-polaris-900/50 border-polaris-800 hover:border-polaris-700 transition-colors">
                <CardContent className="p-6">
                  <div className="p-3 rounded-xl bg-polaris-800/50 mb-4">
                    <item.icon className="h-6 w-6 text-polaris-400" />
                  </div>
                  <h3 className="text-lg font-semibold text-white mb-2">{item.title}</h3>
                  <p className="text-polaris-400">{item.desc}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

function cn(...classes: (string | boolean | undefined)[]) {
  return classes.filter(Boolean).join(' ')
}