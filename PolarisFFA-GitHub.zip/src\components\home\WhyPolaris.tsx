'use client'

import { Card, CardContent } from '@/components/ui/card'
import { Shield, Zap, Users, Award, Globe, Lock, Heart, Bolt } from 'lucide-react'

const features = [
  {
    icon: Shield,
    title: 'Anti-Cheat Protection',
    description: 'Advanced anti-cheat systems ensure fair gameplay for everyone. No hackers, no unfair advantages.',
  },
  {
    icon: Zap,
    title: 'Optimized Performance',
    description: 'Enterprise-grade hardware with custom optimizations for lag-free PvP. 99.9% uptime guarantee.',
  },
  {
    icon: Users,
    title: 'Active Community',
    description: 'Join thousands of active players. Regular events, tournaments, and a friendly Discord community.',
  },
  {
    icon: Award,
    title: 'Fair Progression',
    description: 'Balanced ranking system with cosmetic rewards. No pay-to-win, skill-based progression.',
  },
  {
    icon: Globe,
    title: 'Global Network',
    description: 'Multiple server locations worldwide for low latency. Play from anywhere with great ping.',
  },
  {
    icon: Lock,
    title: 'Secure Payments',
    description: 'Stripe-powered checkout with instant delivery. Your payment info never touches our servers.',
  },
  {
    icon: Heart,
    title: 'Regular Updates',
    description: 'Weekly updates with new features, balance changes, and seasonal content. Always fresh.',
  },
  {
    icon: Bolt,
    title: 'Unique Combat Mechanics',
    description: 'Custom Spear, Mace & Diamond PvP mechanics you won\'t find anywhere else.',
  },
]

export function WhyPolaris() {
  return (
    <section className="section bg-polaris-950">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
            Why Play PolarisFFA?
          </h2>
          <p className="text-polaris-400 text-lg">
            We\'ve built the ultimate FFA experience with features that matter.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => (
            <Card key={index} className="group h-full bg-polaris-950/50 border-polaris-800 hover:border-polaris-700 transition-all duration-300">
              <CardContent className="p-6">
                <div className="p-3 rounded-xl bg-polaris-900/50 border border-polaris-800 group-hover:border-polaris-700 group-hover:bg-polaris-500/10 transition-all duration-300 mb-4">
                  <feature.icon className="h-6 w-6 text-polaris-400 group-hover:text-polaris-300 transition-colors" aria-hidden="true" />
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">{feature.title}</h3>
                <p className="text-polaris-400 text-sm leading-relaxed">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}