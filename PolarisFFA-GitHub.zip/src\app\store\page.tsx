'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardFooter } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Star, Crown, Gem, Sparkles, ShoppingCart, Loader2, ArrowRight } from 'lucide-react'
import { formatPrice } from '@/lib/utils'
import { useSession } from 'next-auth/react'
import { toast } from '@/hooks/use-toast'
import { cn } from '@/lib/utils'

interface Product {
  id: string
  name: string
  description: string
  price: number
  type: string
  active: boolean
  featured: boolean
  sortOrder: number
  metadata: Record<string, unknown> | null
}

const typeLabels: Record<string, { label: string; icon: React.ComponentType<{ className?: string }> }> = {
  rank: { label: 'Rank', icon: Crown },
  cosmetic: { label: 'Cosmetic', icon: Sparkles },
  bundle: { label: 'Bundle', icon: Gem },
}

export default function StorePage() {
  const { data: session } = useSession()
  const router = useRouter()
  const [products, setProducts] = useState<Product[]>([])
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState('all')
  const [cart, setCart] = useState<Record<string, number>>({})

  useEffect(() => {
    fetchProducts()
  }, [])

  const fetchProducts = async () => {
    try {
      const res = await fetch('/api/products')
      if (res.ok) {
        const data = await res.json()
        setProducts(data.filter((p: Product) => p.active))
      }
    } catch (error) {
      console.error('Failed to fetch products:', error)
    } finally {
      setLoading(false)
    }
  }

  const filteredProducts = products.filter((p) => {
    if (activeTab === 'all') return true
    return p.type === activeTab
  })

  const types = ['all', ...Array.from(new Set(products.map((p) => p.type)))]

  const addToCart = (productId: string) => {
    setCart((prev) => ({ ...prev, [productId]: (prev[productId] || 0) + 1 }))
    toast({ title: 'Added to cart', description: 'Product added to your cart' })
  }

  const removeFromCart = (productId: string) => {
    setCart((prev) => {
      const next = { ...prev }
      if (next[productId] > 1) {
        next[productId]--
      } else {
        delete next[productId]
      }
      return next
    })
  }

  const cartItems = Object.entries(cart).map(([productId, quantity]) => {
    const product = products.find((p) => p.id === productId)
    return product ? { product, quantity } : null
  }).filter(Boolean)

  const cartTotal = cartItems.reduce((sum, item) => sum + (item!.product.price * item!.quantity), 0)

  return (
    <div className="min-h-[calc(100vh-16rem)]">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h1 className="text-4xl sm:text-5xl font-bold text-white mb-4">Store</h1>
            <p className="text-polaris-400 text-lg max-w-2xl mx-auto">
              Browse our selection of ranks, cosmetics, and bundles. All purchases support the server.
            </p>
          </div>

          {loading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {[...Array(6)].map((_, i) => (
                <Card key={i} className="animate-pulse bg-polaris-950/50 border-polaris-800">
                  <CardContent className="p-6">
                    <div className="h-32 bg-polaris-800 rounded-lg mb-4" />
                    <div className="h-4 bg-polaris-800 rounded w-3/4 mb-2" />
                    <div className="h-4 bg-polaris-800 rounded w-1/2" />
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <>
              <div className="mb-8">
                <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                  <TabsList className="grid w-full grid-cols-4 sm:grid-cols-5">
                    {types.map((type) => (
                      <TabsTrigger key={type} value={type} className="capitalize">
                        {type === 'all' ? 'All' : typeLabels[type]?.label || type}
                      </TabsTrigger>
                    ))}
                  </TabsList>
                </Tabs>
              </div>

              {filteredProducts.length === 0 ? (
                <div className="text-center py-16">
                  <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-polaris-900/50 border border-polaris-800">
                    <Crown className="h-8 w-8 text-polaris-500" />
                  </div>
                  <h3 className="text-xl font-semibold text-white mb-2">No products found</h3>
                  <p className="text-polaris-400">Check back later for new items!</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredProducts.map((product) => {
                    const typeInfo = typeLabels[product.type] || { label: product.type, icon: Gem }
                    const TypeIcon = typeInfo.icon
                    const inCart = cart[product.id] || 0

                    return (
                      <Card key={product.id} className="group relative overflow-hidden bg-polaris-950/50 border-polaris-800 hover:border-polaris-700 transition-all duration-300 h-full flex flex-col">
                        {product.featured && (
                          <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-polaris-400 to-polaris-600 z-10" />
                        )}
                        <CardContent className="p-6 flex-1 flex flex-col">
                          <div className="flex items-start justify-between mb-4">
                            <div className={cn('p-3 rounded-xl', product.featured ? 'bg-gradient-to-br from-polaris-500 to-polaris-400' : 'bg-polaris-900/50 border border-polaris-800')}>
                              <TypeIcon className={cn('h-6 w-6', product.featured ? 'text-white' : 'text-polaris-400')} />
                            </div>
                            {product.featured && (
                              <Badge variant="premium" className="text-xs">
                                <Sparkles className="h-3 w-3 mr-1" />
                                Featured
                              </Badge>
                            )}
                          </div>
                          <div className="flex items-center gap-2 mb-2">
                            <Badge variant="outline" className="text-xs">{typeInfo.label}</Badge>
                          </div>
                          <h3 className="text-xl font-bold text-white mb-2">{product.name}</h3>
                          <p className="text-polaris-400 text-sm mb-4 flex-1">{product.description}</p>
                          <div className="flex items-center justify-between pt-4 border-t border-polaris-800">
                            <span className="text-2xl font-bold text-white">{formatPrice(product.price)}</span>
                            {inCart > 0 ? (
                              <div className="flex items-center gap-2">
                                <Button variant="outline" size="icon" onClick={() => removeFromCart(product.id)}>
                                  <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 12H4" /></svg>
                                </Button>
                                <span className="text-white font-medium w-8 text-center">{inCart}</span>
                                <Button variant="outline" size="icon" onClick={() => addToCart(product.id)} className="bg-polaris-500/20 hover:bg-polaris-500/30">
                                  <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" /></svg>
                                </Button>
                              </div>
                            ) : (
                              <Button
                                className={cn('gap-2', product.featured ? 'bg-gradient-to-r from-polaris-600 to-polaris-400 hover:from-polaris-500 hover:to-polaris-300' : '')}
                                onClick={() => addToCart(product.id)}
                              >
                                <ShoppingCart className="h-4 w-4" />
                                Add to Cart
                              </Button>
                            )}
                          </div>
                        </CardContent>
                      </Card>
                    )
                  })}
                </div>
              )}
            </>
          )}

          {cartItems.length > 0 && (
            <div className="fixed bottom-4 right-4 z-50 animate-in slide-in-from-bottom-4">
              <Card className="w-80 shadow-2xl border-polaris-700">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="font-semibold text-white flex items-center gap-2">
                      <ShoppingCart className="h-5 w-5" />
                      Cart ({cartItems.length})
                    </h3>
                  </div>
                  <div className="space-y-2 max-h-60 overflow-y-auto">
                    {cartItems.map((item) => (
                      <div key={item!.product.id} className="flex items-center justify-between gap-2 p-2 bg-polaris-900/50 rounded-lg">
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-white truncate">{item!.product.name}</p>
                          <p className="text-xs text-polaris-400">{formatPrice(item!.product.price)} each</p>
                        </div>
                        <div className="flex items-center gap-2">
<Button variant="outline" size="icon" onClick={() => removeFromCart(item!.product.id)}>
                              <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 12H4" /></svg>
                            </Button>
                          <span className="text-white font-medium w-6 text-center">{item!.quantity}</span>
<Button variant="outline" size="icon" onClick={() => addToCart(item!.product.id)} className="bg-polaris-500/20 hover:bg-polaris-500/30">
                              <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" /></svg>
                            </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                  <div className="border-t border-polaris-800 pt-4 mt-4">
                    <div className="flex justify-between mb-3">
                      <span className="text-polaris-300">Total</span>
                      <span className="text-xl font-bold text-white">{formatPrice(cartTotal)}</span>
                    </div>
                    <Button className="w-full" onClick={() => router.push('/checkout')}>
                      <ArrowRight className="h-4 w-4" />
                      Checkout
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}