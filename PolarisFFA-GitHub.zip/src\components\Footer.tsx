'use client'

import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'
import { MessageSquare, Youtube, Server, Mail, Copy, Check, Video } from 'lucide-react'
import { useState } from 'react'

const DiscordIcon = ({ className }: { className?: string }) => (
  <svg className={className} fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
    <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.442.747-.694 1.113a18.8 18.8 0 0 0-5.453 0 13.53 13.53 0 0 0-.711-1.113.077.077 0 0 0-.079-.037A19.735 19.735 0 0 0 3.676 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.083.083 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028 14.09 14.09 0 0 0 1.226-1.994.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.007-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 0 7.303-2.122 8.93-5.199a.077.077 0 0 1 .077-.01c2.59 0 4.962 1.065 6.648 2.764a.076.076 0 0 1 .032.054 19.914 19.914 0 0 0 5.07-4.329.077.077 0 0 0-.029-.079zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.419-2.157 2.419zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.419-2.157 2.419z" />
  </svg>
)

const YoutubeIcon = ({ className }: { className?: string }) => (
  <Video className={className} />
)

export function Footer() {
  const [copied, setCopied] = useState(false)

  const copyIP = async () => {
    await navigator.clipboard.writeText('play.polarisffa.eu')
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const footerLinks = {
    main: [
      { href: '/', label: 'Home' },
      { href: '/store', label: 'Store' },
      { href: '/server', label: 'Server' },
      { href: '/ranks', label: 'Ranks' },
      { href: '/community', label: 'Community' },
      { href: '/support', label: 'Support' },
    ],
    legal: [
      { href: '/rules', label: 'Rules' },
      { href: '/terms', label: 'Terms of Service' },
      { href: '/privacy', label: 'Privacy Policy' },
      { href: '/refund', label: 'Refund Policy' },
    ],
    social: [
      { href: 'https://discord.gg/HutBfhABcJ', label: 'Discord', external: true, icon: DiscordIcon },
      { href: 'https://www.youtube.com/@PolarisFFA', label: 'YouTube', external: true, icon: YoutubeIcon },
    ],
  }

  return (
    <footer className="border-t border-polaris-800 bg-polaris-950/50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16">
        <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-4">
          <div className="lg:col-span-1">
            <Link href="/" className="flex items-center space-x-2 mb-6" aria-label="PolarisFFA Home">
              <div className="relative flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-to-br from-polaris-500 to-polaris-700">
                <svg className="h-6 w-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" />
                </svg>
              </div>
              <span className="text-xl font-bold tracking-tight text-white">PolarisFFA</span>
            </Link>
            <p className="text-polaris-400 text-sm leading-relaxed mb-6">
              Minecraft FFA Server — Spear, Mace & Diamond SMP combat experience.
              Join our community for competitive PvP and progression.
            </p>
            <div className="flex items-center gap-4">
              <a
                href="https://discord.gg/HutBfhABcJ"
                target="_blank"
                rel="noopener noreferrer"
                className="text-polaris-400 hover:text-white transition-colors"
                aria-label="Discord"
              >
                <DiscordIcon />
              </a>
              <a
                href="https://www.youtube.com/@PolarisFFA"
                target="_blank"
                rel="noopener noreferrer"
                className="text-polaris-400 hover:text-white transition-colors"
                aria-label="YouTube"
              >
                <YoutubeIcon />
              </a>
            </div>
          </div>

          <div>
            <h3 className="text-white font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              {footerLinks.main.map((link) => (
                <li key={link.href}>
                  <Link href={link.href} className="text-polaris-400 hover:text-white transition-colors text-sm">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="text-white font-semibold mb-4">Legal</h3>
            <ul className="space-y-2">
              {footerLinks.legal.map((link) => (
                <li key={link.href}>
                  <Link href={link.href} className="text-polaris-400 hover:text-white transition-colors text-sm">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="text-white font-semibold mb-4">Connect</h3>
            <div className="space-y-3">
              <div className="flex items-center gap-3 p-3 rounded-lg bg-polaris-900/50 border border-polaris-800">
                <Server className="h-5 w-5 text-polaris-400 flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-xs text-polaris-500 uppercase tracking-wider">Server IP</p>
                  <div className="flex items-center gap-2">
                    <code className="text-sm text-white font-mono break-all">play.polarisffa.eu</code>
                    <Button variant="ghost" size="icon" onClick={copyIP} className="h-8 w-8 p-0">
                      {copied ? <Check className="h-4 w-4 text-green-400" /> : <Copy className="h-4 w-4" />}
                    </Button>
                  </div>
                </div>
              </div>
              <a
                href="https://discord.gg/HutBfhABcJ"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-3 p-3 rounded-lg bg-polaris-900/50 border border-polaris-800 hover:border-polaris-700 transition-colors"
              >
                <DiscordIcon className="h-5 w-5 text-polaris-400 flex-shrink-0" />
                <div>
                  <p className="text-xs text-polaris-500 uppercase tracking-wider">Discord</p>
                  <p className="text-sm text-white">discord.gg/HutBfhABcJ</p>
                </div>
              </a>
              <a
                href="https://www.youtube.com/@PolarisFFA"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-3 p-3 rounded-lg bg-polaris-900/50 border border-polaris-800 hover:border-polaris-700 transition-colors"
              >
                <YoutubeIcon className="text-red-400" />
                <div>
                  <p className="text-xs text-polaris-500 uppercase tracking-wider">YouTube</p>
                  <p className="text-sm text-white">@PolarisFFA</p>
                </div>
              </a>
            </div>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-polaris-800">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-polaris-500 text-sm">
              © {new Date().getFullYear()} PolarisFFA. All rights reserved.
            </p>
            <p className="text-polaris-500 text-sm">
              Not affiliated with Mojang Studios or Microsoft.
            </p>
          </div>
        </div>
      </div>
    </footer>
  )
}