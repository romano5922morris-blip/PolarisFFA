'use client'

import * as React from 'react'
import { cva, type VariantProps } from 'class-variance-authority'
import { cn } from '@/lib/utils'

const badgeVariants = cva(
  'inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2',
  {
    variants: {
      variant: {
        default: 'border-transparent bg-polaris-700 text-polaris-100 hover:bg-polaris-600',
        secondary: 'border-polaris-700 bg-transparent text-polaris-300 hover:bg-polaris-800/50',
        destructive: 'border-transparent bg-red-900/50 text-red-300 hover:bg-red-900 border-red-800',
        outline: 'border-polaris-700 text-polaris-300',
        success: 'border-transparent bg-green-900/50 text-green-300 hover:bg-green-900 border-green-800',
        premium: 'border-transparent bg-gradient-to-r from-polaris-600 to-polaris-400 text-white shadow-lg shadow-polaris-500/30',
        // Role badge variants
        'role-user': 'bg-gray-800 text-gray-300',
        'role-helper': 'bg-blue-900/50 text-blue-300 border-blue-800',
        'role-admin': 'bg-green-900/50 text-green-300 border-green-800',
        'role-head_admin': 'bg-purple-900/50 text-purple-300 border-purple-800',
        'role-co_owner': 'bg-orange-900/50 text-orange-300 border-orange-800',
        'role-owner': 'bg-red-900/50 text-red-300 border-red-800',
      },
    },
    defaultVariants: {
      variant: 'default',
    },
  }
)

export interface BadgeProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof badgeVariants> {}

function Badge({ className, variant, ...props }: BadgeProps) {
  return <div className={cn(badgeVariants({ variant }), className)} {...props} />
}

export { Badge, badgeVariants }