import { Resend } from 'resend'

const resend = process.env.RESEND_API_KEY ? new Resend(process.env.RESEND_API_KEY) : null

export async function sendVerificationEmail(email: string, token: string, username: string) {
  if (!resend) {
    console.log('[DEV] Verification email would be sent to:', email, 'Token:', token)
    return { success: true, dev: true }
  }

  const verifyUrl = `${process.env.NEXTAUTH_URL}/verify-email?token=${token}`

  try {
    await resend.emails.send({
      from: process.env.EMAIL_FROM!,
      to: email,
      subject: 'Verify your PolarisFFA account',
      html: `
        <div style="font-family: system-ui, sans-serif; max-width: 600px; margin: 0 auto; background: #0c4a6e; padding: 2rem; border-radius: 12px;">
          <div style="text-align: center; margin-bottom: 2rem;">
            <h1 style="color: #0ea5e9; margin: 0; font-size: 2rem;">PolarisFFA</h1>
          </div>
          <h2 style="color: white; margin-top: 0;">Welcome, ${username}!</h2>
          <p style="color: #bae6fd; line-height: 1.6;">Thanks for registering. Please verify your email address to activate your account.</p>
          <div style="text-align: center; margin: 2rem 0;">
            <a href="${verifyUrl}" style="background: #0ea5e9; color: white; padding: 1rem 2rem; border-radius: 8px; text-decoration: none; font-weight: 600; display: inline-block;">Verify Email</a>
          </div>
          <p style="color: #7dd3fc; font-size: 0.875rem;">Or copy this link: ${verifyUrl}</p>
          <hr style="border-color: #0369a1; margin: 2rem 0;">
          <p style="color: #7dd3fc; font-size: 0.75rem;">If you didn't create this account, please ignore this email.</p>
        </div>
      `,
    })
    return { success: true }
  } catch (error) {
    console.error('Failed to send verification email:', error)
    return { success: false, error }
  }
}

export async function sendPasswordResetEmail(email: string, token: string, username: string) {
  if (!resend) {
    console.log('[DEV] Password reset email would be sent to:', email, 'Token:', token)
    return { success: true, dev: true }
  }

  const resetUrl = `${process.env.NEXTAUTH_URL}/reset-password?token=${token}`

  try {
    await resend.emails.send({
      from: process.env.EMAIL_FROM!,
      to: email,
      subject: 'Reset your PolarisFFA password',
      html: `
        <div style="font-family: system-ui, sans-serif; max-width: 600px; margin: 0 auto; background: #0c4a6e; padding: 2rem; border-radius: 12px;">
          <div style="text-align: center; margin-bottom: 2rem;">
            <h1 style="color: #0ea5e9; margin: 0; font-size: 2rem;">PolarisFFA</h1>
          </div>
          <h2 style="color: white; margin-top: 0;">Password Reset Request</h2>
          <p style="color: #bae6fd; line-height: 1.6;">Hi ${username}, you requested a password reset. Click the button below to set a new password.</p>
          <div style="text-align: center; margin: 2rem 0;">
            <a href="${resetUrl}" style="background: #0ea5e9; color: white; padding: 1rem 2rem; border-radius: 8px; text-decoration: none; font-weight: 600; display: inline-block;">Reset Password</a>
          </div>
          <p style="color: #7dd3fc; font-size: 0.875rem;">Or copy this link: ${resetUrl}</p>
          <p style="color: #7dd3fc; font-size: 0.75rem;">This link expires in 1 hour.</p>
          <hr style="border-color: #0369a1; margin: 2rem 0;">
          <p style="color: #7dd3fc; font-size: 0.75rem;">If you didn't request this, please ignore this email.</p>
        </div>
      `,
    })
    return { success: true }
  } catch (error) {
    console.error('Failed to send password reset email:', error)
    return { success: false, error }
  }
}

export async function sendOrderConfirmationEmail(email: string, username: string, orderId: string, items: Array<{ name: string; price: number }>) {
  if (!resend) {
    console.log('[DEV] Order confirmation email would be sent to:', email)
    return { success: true, dev: true }
  }

  const itemsHtml = items.map(item => `
    <tr>
      <td style="padding: 0.75rem; color: #bae6fd;">${item.name}</td>
      <td style="padding: 0.75rem; color: #bae6fd; text-align: right;">$${(item.price / 100).toFixed(2)}</td>
    </tr>
  `).join('')

  const total = items.reduce((sum, item) => sum + item.price, 0)

  try {
    await resend.emails.send({
      from: process.env.EMAIL_FROM!,
      to: email,
      subject: `Order Confirmation #${orderId.slice(0, 8)} - PolarisFFA`,
      html: `
        <div style="font-family: system-ui, sans-serif; max-width: 600px; margin: 0 auto; background: #0c4a6e; padding: 2rem; border-radius: 12px;">
          <div style="text-align: center; margin-bottom: 2rem;">
            <h1 style="color: #0ea5e9; margin: 0; font-size: 2rem;">PolarisFFA</h1>
          </div>
          <h2 style="color: white; margin-top: 0;">Order Confirmed</h2>
          <p style="color: #bae6fd; line-height: 1.6;">Hi ${username}, thank you for your purchase! Your order <strong>#${orderId.slice(0, 8)}</strong> has been confirmed.</p>
          <table style="width: 100%; border-collapse: collapse; margin: 1.5rem 0;">
            <thead>
              <tr style="border-bottom: 1px solid #0369a1;">
                <th style="padding: 0.75rem; text-align: left; color: #0ea5e9;">Item</th>
                <th style="padding: 0.75rem; text-align: right; color: #0ea5e9;">Price</th>
              </tr>
            </thead>
            <tbody>
              ${itemsHtml}
            </tbody>
            <tfoot>
              <tr style="border-top: 2px solid #0ea5e9;">
                <td style="padding: 0.75rem; color: white; font-weight: 600;">Total</td>
                <td style="padding: 0.75rem; color: #0ea5e9; text-align: right; font-weight: 600;">$${(total / 100).toFixed(2)}</td>
              </tr>
            </tfoot>
          </table>
          <p style="color: #7dd3fc; font-size: 0.875rem;">Your ranks/items will be automatically granted in-game. If you have any issues, please <a href="${process.env.NEXTAUTH_URL}/support" style="color: #0ea5e9;">contact support</a>.</p>
        </div>
      `,
    })
    return { success: true }
  } catch (error) {
    console.error('Failed to send order confirmation email:', error)
    return { success: false, error }
  }
}