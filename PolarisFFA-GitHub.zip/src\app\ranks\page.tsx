'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Star, Crown, Gem, Sparkles, Loader2, ArrowRight, Check } from 'lucide-react'
import { formatPrice } from '@/lib/utils'
import { useSession } from 'next-auth/react'
import { toast } from '@/hooks/use-toast'

interface Product {
  id: string
  name: string
  description: string
  price: number
  type: string
  active: boolean
  featured: boolean
  sortOrder: number
  metadata: Record<string, unknown> | null
}

const rankOrder = ['vip', 'mvp', 'elite', 'legend', 'polaris']

export default function RanksPage() {
  const { data: session } = useSession()
  const [products, setProducts] = useState<Product[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchRanks()
  }, [])

  const fetchRanks = async () => {
    try {
      const res = await fetch('/api/products?type=rank')
      if (res.ok) {
        const data = await res.json()
        setProducts(data.filter((p: Product) => p.active && p.type === 'rank'))
      }
    } catch (error) {
      console.error('Failed to fetch ranks:', error)
    } finally {
      setLoading(false)
    }
  }

  const sortedProducts = products.sort((a, b) => {
    const aIndex = rankOrder.indexOf(a.id)
    const bIndex = rankOrder.indexOf(b.id)
    if (aIndex !== -1 && bIndex !== -1) return aIndex - bIndex
    if (aIndex !== -1) return -1
    if (bIndex !== -1) return 1
    return b.sortOrder - a.sortOrder
  })

  return (
    <div className="min-h-[calc(100vh-16rem)]">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h1 className="text-4xl sm:text-5xl font-bold text-white mb-4">Ranks</h1>
            <p className="text-polaris-400 text-lg max-w-2xl mx-auto">
              Support the server and unlock exclusive perks, cosmetics, and gameplay advantages.
            </p>
          </div>

          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[...Array(6)].map((_, i) => (
                <Card key={i} className="animate-pulse bg-polaris-950/50 border-polaris-800">
                  <CardContent className="p-6">
                    <div className="h-32 bg-polaris-800 rounded-lg mb-4" />
                    <div className="h-4 bg-polaris-800 rounded w-3/4 mb-2" />
                    <div className="h-4 bg-polaris-800 rounded w-1/2" />
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {sortedProducts.map((rank) => (
                <Card key={rank.id} className="relative overflow-hidden bg-polaris-950/50 border-polaris-800 hover:border-polaris-700 transition-all duration-300 h-full flex flex-col">
                  {rank.featured && (
                    <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-polaris-400 to-polaris-600" />
                  )}
                  <CardContent className="p-6 flex-1 flex flex-col">
                    <div className="flex items-start justify-between mb-4">
                      <div className="p-3 rounded-xl bg-polaris-900/50 border border-polaris-800">
                        <Crown className="h-6 w-6 text-polaris-400" />
                      </div>
                      {rank.featured && (
                        <Badge variant="premium" className="text-xs">
                          <Sparkles className="h-3 w-3 mr-1" />
                          Featured
                        </Badge>
                      )}
                    </div>
                    <h3 className="text-2xl font-bold text-white mb-2">{rank.name}</h3>
                    <p className="text-polaris-400 text-sm mb-6 flex-1">{rank.description}</p>
                    <div className="mb-6">
                      <span className="text-4xl font-bold text-white">{formatPrice(rank.price)}</span>
                      <span className="text-polaris-500 ml-2">one-time</span>
                    </div>
                    <ul className="space-y-3 mb-6 flex-1">
                      {(rank.metadata?.benefits as string[] || []).map((benefit, index) => (
                        <li key={index} className="flex items-start gap-3 text-polaris-300 text-sm">
                          <Check className="h-5 w-5 text-polaris-400 flex-shrink-0 mt-0.5" />
                          <span>{benefit}</span>
                        </li>
                      ))}
                    </ul>
                    <Button
                      className={cn('w-full', rank.featured ? 'bg-gradient-to-r from-polaris-600 to-polaris-400 hover:from-polaris-500 hover:to-polaris-300' : '')}
                      onClick={() => session ? window.location.href = `/checkout?product=${rank.id}` : window.location.href = `/login?callbackUrl=/checkout?product=${rank.id}`}
                    >
                      {session ? 'Purchase' : 'Login to Purchase'}
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

function cn(...classes: (string | boolean | undefined)[]) {
  return classes.filter(Boolean).join(' ')
}