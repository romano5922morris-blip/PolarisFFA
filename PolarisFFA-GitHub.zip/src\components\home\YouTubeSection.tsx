'use client'

import { Button } from '@/components/ui/button'
import { Video, Play, ArrowRight, TrendingUp, Clock } from 'lucide-react'
import Link from 'next/link'

const YoutubeIcon = ({ className }: { className?: string }) => (
  <Video className={className} />
)

const SubscribeIcon = ({ className }: { className?: string }) => (
  <svg className={className} fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
    <path d="M15 21v-3a3 3 0 1 0-6 0v3a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1v-4a1 1 0 0 1 1-1h2.5a1 1 0 0 0 0-2H4a2 2 0 0 0-2 2v4a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-4a2 2 0 0 0-2-2h-2.5a1 1 0 0 0 0 2H20a1 1 0 0 1 1 1v4a1 1 0 0 1-1 1h-4a1 1 0 0 1-1-1Z" />
    <path d="M12 3v12a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1v-4a1 1 0 0 1 1-1h2.5a1 1 0 0 0 0-2H4a2 2 0 0 0-2 2v4a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-4a2 2 0 0 0-2-2h-2.5a1 1 0 0 0 0 2H20a1 1 0 0 1 1 1v4a1 1 0 0 1-1 1h-4a1 1 0 0 1-1-1Z" />
  </svg>
)

export function YouTubeSection() {
  const videos = [
    {
      title: 'PolarisFFA Trailer - Official Release',
      views: '125K views',
      duration: '2:34',
      thumbnail: 'https://img.youtube.com/vi/dQw4w9WgXcQ/maxresdefault.jpg',
      videoId: 'dQw4w9WgXcQ',
    },
    {
      title: 'Spear Combat Guide - Advanced Tips',
      views: '45K views',
      duration: '8:12',
      thumbnail: 'https://img.youtube.com/vi/dQw4w9WgXcQ/maxresdefault.jpg',
      videoId: 'dQw4w9WgXcQ',
    },
    {
      title: 'Mace Mechanics Explained',
      views: '38K views',
      duration: '6:45',
      thumbnail: 'https://img.youtube.com/vi/dQw4w9WgXcQ/maxresdefault.jpg',
      videoId: 'dQw4w9WgXcQ',
    },
    {
      title: 'Diamond PvP Tournament Finals',
      views: '67K views',
      duration: '15:30',
      thumbnail: 'https://img.youtube.com/vi/dQw4w9WgXcQ/maxresdefault.jpg',
      videoId: 'dQw4w9WgXcQ',
    },
  ]

  return (
    <section className="section bg-polaris-900/30 border-y border-polaris-800/50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-12">
            <div>
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-red-900/30 border border-red-800 text-red-300 text-sm font-medium mb-4">
                <YoutubeIcon className="h-4 w-4" aria-hidden="true" />
                <span>Official Channel</span>
              </div>
              <h2 className="text-3xl sm:text-4xl font-bold text-white mb-2">
                YouTube Content
              </h2>
              <p className="text-polaris-400">
                Tutorials, tournaments, guides, and epic gameplay moments.
              </p>
            </div>
            <a href="https://www.youtube.com/@PolarisFFA" target="_blank" rel="noopener noreferrer">
              <Button variant="outline" size="lg" className="gap-2 border-red-500 text-red-300 hover:bg-red-500/10">
                <YoutubeIcon className="h-5 w-5" aria-hidden="true" />
                Subscribe
                <SubscribeIcon className="h-4 w-4" aria-hidden="true" />
              </Button>
            </a>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {videos.map((video, index) => (
              <article key={index} className="group relative bg-polaris-950/50 border border-polaris-800 rounded-xl overflow-hidden transition-all duration-300 hover:border-polaris-700 hover:shadow-xl hover:shadow-polaris-500/10">
                <div className="relative aspect-video overflow-hidden">
                  <img 
                    src={video.thumbnail} 
                    alt={video.title}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                  <div className="absolute bottom-3 right-3 bg-black/90 text-white text-xs px-2 py-1 rounded font-mono">
                    {video.duration}
                  </div>
                  <a 
                    href={`https://www.youtube.com/watch?v=${video.videoId}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                    aria-label={`Watch ${video.title}`}
                  >
                    <div className="p-3 rounded-full bg-white/10 backdrop-blur-sm text-white transform group-hover:scale-110 transition-transform">
                      <Play className="h-8 w-8 ml-1" aria-hidden="true" />
                    </div>
                  </a>
                </div>
                <div className="p-4">
                  <h3 className="font-semibold text-white text-sm mb-1 line-clamp-2 group-hover:text-polaris-300 transition-colors">
                    {video.title}
                  </h3>
                  <div className="flex items-center gap-3 text-polaris-500 text-xs">
                    <span className="flex items-center gap-1">
                      <TrendingUp className="h-3 w-3" aria-hidden="true" />
                      {video.views}
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="h-3 w-3" aria-hidden="true" />
                      {video.duration}
                    </span>
                  </div>
                </div>
              </article>
            ))}
          </div>

          <div className="text-center mt-10">
            <a href="https://www.youtube.com/@PolarisFFA" target="_blank" rel="noopener noreferrer">
              <Button variant="outline" size="lg" className="gap-2 border-polaris-600 hover:border-polaris-400">
                View All Videos
                <ArrowRight className="h-4 w-4" aria-hidden="true" />
              </Button>
            </a>
          </div>
        </div>
      </div>
    </section>
  )
}