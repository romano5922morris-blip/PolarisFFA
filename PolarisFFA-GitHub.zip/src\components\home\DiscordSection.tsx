'use client'

import { Button } from '@/components/ui/button'
import { ArrowRight, Users, MessageSquare, Shield, Crown } from 'lucide-react'
import Link from 'next/link'

const DiscordIcon = ({ className }: { className?: string }) => (
  <svg className={className} fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
    <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.442.747-.694 1.113a18.8 18.8 0 0 0-5.453 0 13.53 13.53 0 0 0-.711-1.113.077.077 0 0 0-.079-.037A19.735 19.735 0 0 0 3.676 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.083.083 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028 14.09 14.09 0 0 0 1.226-1.994.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.007-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 0 7.303-2.122 8.93-5.199a.077.077 0 0 1 .077-.01c2.59 0 4.962 1.065 6.648 2.764a.076.076 0 0 1 .032.054 19.914 19.914 0 0 0 5.07-4.329.077.077 0 0 0-.029-.079zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.419-2.157 2.419zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.419-2.157 2.419z" />
  </svg>
)

export function DiscordSection() {
  return (
    <section className="section bg-gradient-to-br from-polaris-900/50 via-purple-900/10 to-polaris-950 border-y border-polaris-800/50 relative overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-purple-900/20 via-transparent to-transparent" aria-hidden="true" />
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="max-w-4xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="text-center lg:text-left">
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-purple-900/30 border border-purple-800 text-purple-300 text-sm font-medium mb-6">
                <DiscordIcon className="h-4 w-4" aria-hidden="true" />
                <span>Official Community</span>
              </div>
              
              <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
                Join Our Discord
              </h2>
              
              <p className="text-polaris-300 text-lg mb-8 leading-relaxed">
                Connect with 5,000+ players, get real-time support, participate in events, 
                and stay updated with the latest server news.
              </p>

              <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4 mb-8">
                <a href="https://discord.gg/HutBfhABcJ" target="_blank" rel="noopener noreferrer">
                  <Button size="lg" className="group gap-2 bg-gradient-to-r from-purple-600 to-purple-500 hover:from-purple-500 hover:to-purple-400 shadow-lg shadow-purple-500/30 w-full sm:w-auto">
                    <DiscordIcon className="h-5 w-5" aria-hidden="true" />
                    Join Discord
                    <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" aria-hidden="true" />
                  </Button>
                </a>
                <Button variant="outline" size="lg" className="w-full sm:w-auto border-purple-500 text-purple-300 hover:bg-purple-500/10">
                  <MessageSquare className="h-5 w-5 mr-2" aria-hidden="true" />
                  View Channels
                </Button>
              </div>

              <div className="flex flex-wrap items-center justify-center lg:justify-start gap-6 text-polaris-400 text-sm">
                <div className="flex items-center gap-2">
                  <Users className="h-4 w-4 text-purple-400" aria-hidden="true" />
                  <span>5,000+ Members</span>
                </div>
                <div className="flex items-center gap-2">
                  <Shield className="h-4 w-4 text-purple-400" aria-hidden="true" />
                  <span>24/7 Support</span>
                </div>
                <div className="flex items-center gap-2">
                  <Crown className="h-4 w-4 text-purple-400" aria-hidden="true" />
                  <span>Exclusive Roles</span>
                </div>
              </div>
            </div>

            <div className="relative">
              <div className="rounded-2xl overflow-hidden border border-purple-800/50 bg-polaris-950/50 shadow-2xl shadow-purple-500/10">
                <div className="flex items-center gap-2 px-4 py-3 bg-polaris-900/50 border-b border-purple-800/50">
                  <div className="flex gap-1.5">
                    <div className="h-3 w-3 rounded-full bg-red-500" />
                    <div className="h-3 w-3 rounded-full bg-yellow-500" />
                    <div className="h-3 w-3 rounded-full bg-green-500" />
                  </div>
                  <div className="flex-1 text-center text-polaris-500 text-xs font-mono">discord.gg/HutBfhABcJ</div>
                </div>
                <div className="p-6 space-y-4">
                  <div className="flex items-start gap-3 p-3 rounded-lg bg-polaris-900/50 border border-polaris-800">
                    <div className="h-10 w-10 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex-shrink-0" />
                    <div>
                      <div className="flex items-center gap-2 text-white font-medium">
                        <span>PolarisBot</span>
                        <span className="text-xs text-purple-300 bg-purple-900/30 px-2 py-0.5 rounded">BOT</span>
                      </div>
                      <p className="text-polaris-300 text-sm mt-1">Welcome to PolarisFFA! Check out #announcements for the latest updates.</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3 p-3 rounded-lg bg-polaris-900/50 border border-polaris-800">
                    <div className="h-10 w-10 rounded-full bg-gradient-to-br from-polaris-400 to-polaris-600 flex-shrink-0" />
                    <div>
                      <div className="flex items-center gap-2 text-white font-medium">
                        <span>Admin</span>
                        <span className="text-xs text-polaris-300 bg-polaris-900/30 px-2 py-0.5 rounded">STAFF</span>
                      </div>
                      <p className="text-polaris-300 text-sm mt-1">Tournament this Saturday at 3 PM UTC! $100 prize pool. Register in #events 🏆</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3 p-3 rounded-lg bg-polaris-900/50 border border-polaris-800">
                    <div className="h-10 w-10 rounded-full bg-gradient-to-br from-yellow-500 to-orange-500 flex-shrink-0" />
                    <div>
                      <div className="flex items-center gap-2 text-white font-medium">
                        <span>Player123</span>
                        <span className="text-xs text-yellow-300 bg-yellow-900/30 px-2 py-0.5 rounded">MVP</span>
                      </div>
                      <p className="text-polaris-300 text-sm mt-1">Just got ELITE rank! The particle trails are amazing ✨ Thanks PolarisFFA!</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}