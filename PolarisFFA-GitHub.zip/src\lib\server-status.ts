interface MinecraftServerStatus {
  online: boolean
  playersOnline: number
  playersMax: number
  version?: string
  motd?: string
  latency?: number
  error?: string
}

const CACHE_DURATION = 30000 // 30 seconds
let cachedStatus: MinecraftServerStatus | null = null
let lastFetch = 0

export async function getServerStatus(): Promise<MinecraftServerStatus> {
  const now = Date.now()
  
  if (cachedStatus && now - lastFetch < CACHE_DURATION) {
    return cachedStatus
  }

  const serverIp = process.env.MINECRAFT_SERVER_IP || 'play.polarisffa.eu'
  const serverPort = process.env.MINECRAFT_SERVER_PORT || '25565'
  
  try {
    // Using mcsrvstat.us API
    const response = await fetch(`https://api.mcsrvstat.us/3/${serverIp}:${serverPort}`, {
      next: { revalidate: 30 },
      headers: {
        'Accept': 'application/json',
      },
    })

    if (!response.ok) {
      throw new Error(`API responded with ${response.status}`)
    }

    const data = await response.json()

    const status: MinecraftServerStatus = {
      online: data.online === true,
      playersOnline: data.players?.online || 0,
      playersMax: data.players?.max || 0,
      version: data.version,
      motd: data.motd?.clean ? data.motd.clean.join('\n') : data.motd?.raw,
      latency: data.debug?.ping,
    }

    cachedStatus = status
    lastFetch = now

    // Also save to database for history
    await saveServerStatus(status).catch(console.error)

    return status
  } catch (error) {
    console.error('Failed to fetch server status:', error)
    
    const errorStatus: MinecraftServerStatus = {
      online: false,
      playersOnline: 0,
      playersMax: 0,
      error: error instanceof Error ? error.message : 'Unknown error',
    }

    cachedStatus = errorStatus
    lastFetch = now

    return errorStatus
  }
}

async function saveServerStatus(status: MinecraftServerStatus) {
  const { prisma } = await import('./prisma')
  
  await prisma.serverStatus.create({
    data: {
      online: status.online,
      playersOnline: status.playersOnline,
      playersMax: status.playersMax,
      version: status.version,
      motd: status.motd,
      latency: status.latency,
    },
  })

  // Keep only last 1000 records
  const count = await prisma.serverStatus.count()
  if (count > 1000) {
    const oldest = await prisma.serverStatus.findMany({
      take: count - 1000,
      orderBy: { checkedAt: 'asc' },
      select: { id: true },
    })
    await prisma.serverStatus.deleteMany({
      where: { id: { in: oldest.map((o: { id: string }) => o.id) } },
    })
  }
}

export function getCachedStatus(): MinecraftServerStatus | null {
  return cachedStatus
}